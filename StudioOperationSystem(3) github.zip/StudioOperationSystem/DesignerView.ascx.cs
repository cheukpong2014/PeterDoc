﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Services.Localization;
using DotNetNuke.Security;
using Milton.Modules.StudioOperationSystem.Components;
using DotNetNuke.Entities.Users;

namespace Milton.Modules.StudioOperationSystem
{
    public partial class DesignerView : StudioOperationSystemModuleBase, IActionable
    {
        public ModuleActionCollection ModuleActions
        {
            get
            {
                var actions = new ModuleActionCollection
                    {
                        {
                            GetNextActionID(), Localization.GetString("EditModule", LocalResourceFile), "", "", "",
                            EditUrl(), false, SecurityAccessLevel.Edit, true, false
                        }
                    };
                return actions;
            }
        }       

        protected void Page_Load(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterClientScriptInclude("datatable", "/Plug-in/DataTables/media/js/jquery.dataTables.min.js");
            Page.ClientScript.RegisterClientScriptInclude("datatableTableTools", "/Plug-in/DataTables/extensions/TableTools/js/dataTables.tableTools.min.js");
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "datatablesCSS", "<link rel='stylesheet' type='text/css' href='/Plug-in/DataTables/media/css/jquery.dataTables.css'>");
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "datatablesTableToolsCSS", "<link rel='stylesheet' type='text/css' href='/Plug-in/DataTables/extensions/TableTools/css/dataTables.tableTools.css'>");

            var TeamMemberCtl = new TeamMemberController();
            var TeamMemberStatusCtl = new TeamMemberStatusController();

            if (!IsPostBack)
            {
                var allDesigner = TeamMemberCtl.GetExistingDesigners().ToList();
                List<Components.TeamMember> filter = allDesigner;

                var result = filter.Select(designer => new NewDesigner
                {
                    ID = designer.ID,
                    StaffID = designer.StaffID,
                    Name = UserController.GetUserById(PortalId, designer.StaffID).DisplayName,                    
                    JobLevel = designer.JobLevel,
                    HourlyRate = designer.HourlyRate,
                    Remark = designer.Remark,
                    Status = TeamMemberStatusCtl.GetStatusDescription(designer.Status).Count() == 1 ? Localization.GetString(TeamMemberStatusCtl.GetStatusDescription(designer.Status).FirstOrDefault().StatusDescription, LocalResourceFile) : Localization.GetString("NA", LocalResourceFile)
                }).ToList();

                if (result.Count() > 0)
                {
                    gvDesigner.DataSource = result;
                    gvDesigner.DataBind();
                    gvDesigner.HeaderRow.TableSection = TableRowSection.TableHeader;
                    gvDesigner.FooterRow.TableSection = TableRowSection.TableFooter;
                }
            }          
        }
        

        protected void btnCreateDesigner_Click(object sender, EventArgs e)
        {
            Response.Redirect(EditUrl("DesignerId", "", "DesignerDetails"));
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL());
        }

        protected void gvTable_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            e.Row.Cells[0].CssClass = "hiddenColumn";
            e.Row.Cells[1].CssClass = "hiddenColumn";
            e.Row.Cells[3].CssClass = "hiddenColumn";
        }

    }
}

public class NewDesigner
{
    public int ID { get; set; }
    public int StaffID { get; set; }
    public string Name { get; set; }    
    public int JobLevel { get; set; }
    public double HourlyRate { get; set; }
    public string Remark { get; set; }
    public string Status { get; set; }
}