﻿/*
' Copyright (c) 2016  Milton-Exhibits
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using System;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Services.Mail;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace Milton.Modules.StudioOperationSystem
{
    public class StudioOperationSystemModuleBase : PortalModuleBase
    {
        public string encryKey
        {
            get { return "Milton"; }
        }

        public byte[] AES_Encrypt(byte[] bytesToBeEncrypted, byte[] passwordBytes)
        {
            byte[] encryptedBytes = null;

            // Set your salt here, change it to meet your flavor:
            // The salt bytes must be at least 8 bytes.
            byte[] saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

            using (MemoryStream ms = new MemoryStream())
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;

                    var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
                    AES.Key = key.GetBytes(AES.KeySize / 8);
                    AES.IV = key.GetBytes(AES.BlockSize / 8);

                    AES.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(ms, AES.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeEncrypted, 0, bytesToBeEncrypted.Length);
                        cs.Close();
                    }
                    encryptedBytes = ms.ToArray();
                }
            }

            return encryptedBytes;
        }

        public string EncryptText(string input, string password)
        {
            // Get the bytes of the string
            byte[] bytesToBeEncrypted = Encoding.UTF8.GetBytes(input);
            byte[] passwordBytes = Encoding.UTF8.GetBytes(password);

            // Hash the password with SHA256
            passwordBytes = SHA256.Create().ComputeHash(passwordBytes);

            byte[] bytesEncrypted = AES_Encrypt(bytesToBeEncrypted, passwordBytes);

            string result = Convert.ToBase64String(bytesEncrypted);

            return result;
        }

        public void SendMail(string strTo, string strCC, string strBCC, string strSubject, string strBody)
        {
            //string strFrom = "noreply@milton-corp.com";
            //System.Collections.Generic.Dictionary<string, string> hostSettings = DotNetNuke.Entities.Controllers.HostController.Instance.GetSettingsDictionary();
            //string strSMTP = hostSettings["SMTPServer"];
            //Mail.SendMail(strFrom, strTo, strCC, strBCC, DotNetNuke.Services.Mail.MailPriority.Normal, strSubject, DotNetNuke.Services.Mail.MailFormat.Html, System.Text.Encoding.UTF8, strBody, "",
            //strSMTP, "1", "NoReply.mc@milton.local", "no689689mc", false);
            string strFrom = "intranet@milton-cn.com";
            System.Collections.Generic.Dictionary<string, string> hostSettings = DotNetNuke.Entities.Controllers.HostController.Instance.GetSettingsDictionary();
            string strSMTP = hostSettings["SMTPServer"];
            Mail.SendMail(strFrom, strTo, strCC, strBCC, DotNetNuke.Services.Mail.MailPriority.Normal, strSubject, DotNetNuke.Services.Mail.MailFormat.Html, System.Text.Encoding.UTF8, strBody, "",
            strSMTP, "1", "intranet.cn", "in123456cn", false);
        }

        public int ItemId
        {
            get
            {
                var qs = Request.QueryString["tid"];
                if (qs != null)
                    return Convert.ToInt32(qs);
                return -1;
            }

        }

        public int BookingID
        {
            get
            {
                var qs = Request.QueryString["BookingID"];
                if (qs != null)
                {
                    return Convert.ToInt32(qs);
                }
                return -1;
            }
        }

        public string BookingStartDate
        {
            get
            {
                var qs = Request.QueryString["BookingStartDate"];
                if (qs != null)
                    return qs.Substring(0, qs.IndexOf('T'));
                return null;
            }
        }

        public string BookingStartTime
        {
            get
            {
                var qs = Request.QueryString["BookingStartDate"];
                if (qs != null)
                {
                    return qs.Remove(0, qs.IndexOf('T') + 1);
                }
                return null;
            }
        }

        public string BookingEndDate
        {
            get
            {
                var qs = Request.QueryString["BookingEndDate"];
                if (qs != null)
                    return qs.Substring(0, qs.IndexOf('T'));
                return null;
            }
        }

        public string BookingEndtTime
        {
            get
            {
                var qs = Request.QueryString["BookingEndDate"];
                if (qs != null)
                {
                    return qs.Remove(0, qs.IndexOf('T') + 1);
                }
                return null;
            }
        }

        public int ProjectId
        {
            get
            {
                var qs = Request.QueryString["ProjectId"];
                if(qs != null)
                {
                    return Convert.ToInt32(qs);
                }
                return -1;
            }
        }

        public int DesignerId
        {
            get
            {
                var qs = Request.QueryString["DesignerId"];
                if (qs != null)
                {
                    return Convert.ToInt32(qs);
                }
                return -1;
            }
        }

    }
}