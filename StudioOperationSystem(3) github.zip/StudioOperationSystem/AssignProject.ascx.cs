﻿using System;
using DotNetNuke.Entities.Users;
using Milton.Modules.StudioOperationSystem.Components;
using DotNetNuke.Services.Exceptions;
using System.Linq;
using System.Globalization;
using System.Collections.Generic;
using System.Web.UI;
using System.Text;
using DotNetNuke.Services.Localization;
using System.Web.UI.WebControls;

namespace Milton.Modules.StudioOperationSystem
{
    public partial class AssignProject : StudioOperationSystemModuleBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    switch (System.Threading.Thread.CurrentThread.CurrentCulture.Name.ToLower())
                    {
                        case "en-us":
                            hfCurrentCulture.Value = string.Empty;
                            break;
                        case "zh-hk":
                        case "zh-cn":
                            hfCurrentCulture.Value = System.Threading.Thread.CurrentThread.CurrentCulture.Name.ToLower();
                            break;
                    }

                    bool isReadOnly = Request.QueryString["ReadOnly"].Equals("Y") ? true : false;

                    hfBookingStartDate.Value = BookingStartDate;
                    hfBookingEndDate.Value = BookingEndDate;
                    hfBookingStartHour.Value = string.IsNullOrWhiteSpace(BookingStartTime) ? string.Empty : BookingStartTime.Split(':').ToArray().Length > 2 ?  BookingStartTime.Split(':').ToArray()[0] : string.Empty;
                    hfBookingStartMinute.Value = string.IsNullOrWhiteSpace(BookingStartTime) ? string.Empty : BookingStartTime.Split(':').ToArray().Length > 2 ? BookingStartTime.Split(':').ToArray()[1] : string.Empty;
                    hfBookingEndHour.Value = string.IsNullOrWhiteSpace(BookingEndtTime) ? string.Empty : BookingEndtTime.Split(':').ToArray().Length > 2 ? BookingEndtTime.Split(':').ToArray()[0] : string.Empty;
                    hfBookingEndMinute.Value = string.IsNullOrWhiteSpace(BookingEndtTime) ? string.Empty : BookingEndtTime.Split(':').ToArray().Length > 2 ? BookingEndtTime.Split(':').ToArray()[1] : string.Empty;

                    BookingDataController bdCtl = new BookingDataController();
                    ProjectControl ptCtl = new ProjectControl();
                    if (BookingID > 0)
                    {
                        var project = ptCtl.GetProject(bdCtl.GetBooking(BookingID).ProjectID);
                        var booking = bdCtl.GetBooking(BookingID);
                        ltlProjectCode.Text = project.Code;
                        ltlShowName.Text = project.ShowName;
                        divBookedBy.InnerText = UserController.GetUserById(PortalId, booking.CreateByUserID).DisplayName;
                        cbRepeatBooking.Visible = false;
                        lblRepeatBooking.Visible = false;
                        hfIsAppendTokenInput.Value = "Y";
                        hfSelectedDesignerName.Value = UserController.GetUserById(PortalId, booking.DesignerID).DisplayName;
                        hfSelectedDesigner.Value = Convert.ToString(booking.DesignerID);
                        btnDelete.Visible = true;
                    }
                    else
                    {
                        if (ProjectId > 0)
                        {
                            hfIsAppendTokenInput.Value = "Y";
                            hfSelectedDesignerName.Value = UserController.GetUserById(PortalId, DesignerId).DisplayName;
                            hfSelectedDesigner.Value = Convert.ToString(DesignerId);
                            var project = ptCtl.GetProject(ProjectId);
                            ltlProjectCode.Text = project.Code;
                            ltlShowName.Text = project.ShowName;
                            lblBookedBy.Visible = false;

                            btnDelete.Visible = false;
                        }
                        else
                        {
                            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "ProjectNotFind", "$('.ui-dialog-titlebar-close').trigger('click'); ", true);
                        }
                    }

                    if (isReadOnly)
                    {
                        btnSubmit.Visible = false;
                        btnDelete.Visible = false;
                    }
                }
            }
            catch (Exception exc)
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            BookingDataController assignedDataCtl = new BookingDataController();
            ViewAssignedDesignerControl ViewAssignedDesignerCtl = new ViewAssignedDesignerControl();                     

            if (!cbRepeatBooking.Checked)
            {
                #region General Booking

                int startDate_Year = Convert.ToInt32(txtBookingStartDate.Text.Trim().Split('-')[0]);
                int startDate_Month = Convert.ToInt32(txtBookingStartDate.Text.Trim().Split('-')[1]);
                int startDate_Day = Convert.ToInt32(txtBookingStartDate.Text.Trim().Split('-')[2]);

                int startTime_Hour = txtBookingStartTime.Text.Trim().Split(' ')[1].ToUpper().Trim().Equals("PM") ? Convert.ToInt32(txtBookingStartTime.Text.Trim().Split(':')[0]) + 12 : Convert.ToInt32(txtBookingStartTime.Text.Trim().Split(':')[0]);
                int startTime_Minute = Convert.ToInt32(txtBookingStartTime.Text.Trim().Split(':')[1].Substring(0,2));
                int endTime_Hour = txtBookingEndTime.Text.Trim().Split(' ')[1].ToUpper().Trim().Equals("PM") ? Convert.ToInt32(txtBookingEndTime.Text.Trim().Split(':')[0]) + 12 : Convert.ToInt32(txtBookingEndTime.Text.Trim().Split(':')[0]);
                int endTime_Minute = Convert.ToInt32(txtBookingEndTime.Text.Trim().Split(':')[1].Substring(0, 2));

                DateTime StartDateTime = new DateTime(startDate_Year, startDate_Month, startDate_Day, startTime_Hour, startTime_Minute, 0);
                DateTime EndDateTime = new DateTime(startDate_Year, startDate_Month, startDate_Day, endTime_Hour, endTime_Minute, 0);

                AssignedSchedule assignedData = new AssignedSchedule();

                assignedData.DesignerID = string.IsNullOrWhiteSpace(hfSelectedDesigner.Value) ? -1 : Convert.ToInt32(hfSelectedDesigner.Value);

                if (BookingID > 0)
                {
                    assignedData.id = BookingID;
                    assignedData.ProjectID = assignedDataCtl.GetBooking(BookingID).ProjectID;
                }
                else if (ProjectId > 0)
                    assignedData.ProjectID = ProjectId;

                var validOverlap = ViewAssignedDesignerCtl.validOverlap(assignedData.DesignerID, StartDateTime, EndDateTime, assignedData.ProjectID);

                if (validOverlap.Count() > 0)
                {
                    List<string> str_list = new List<string>();
                    foreach (var overlap in validOverlap)
                        str_list.Add(overlap.start.ToString("yyyy-MM-dd hh:mm tt") + " - " + overlap.end.ToString("yyyy-MM-dd hh:mm tt") + "\\n" + overlap.ProjectCode + "\\r\\n");

                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "alertColiding", string.Format(LocalizeString("errCollidingDate"), validOverlap.Count(), string.Join(string.Empty, str_list)), true);
                    return;
                }      

                assignedData.start = StartDateTime;
                assignedData.end = EndDateTime;
                
                assignedData.CreateByUserID = UserId;

                if (assignedData.DesignerID == -1)
                {
                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "notFindDesigner", "alert('" + LocalizeString("errmsg_DesignerMissing") + "');", true);
                    return;
                }
                else
                {
                    if (BookingID > 0)
                    {
                        assignedDataCtl.UpdateBooking(assignedData);
                        var designer = ViewAssignedDesignerCtl.GetAssignedDesigner(BookingID);
                        sendNoticeMail("U", designer);
                    }
                    else
                    {
                        assignedDataCtl.CreateBooking(assignedData);
                        var designer = ViewAssignedDesignerCtl.GetAssignedDesigner(assignedData.id);
                        sendNoticeMail("N", designer);
                    }
                }

            #endregion     
            }            
            else
            {
                #region Repeat Booking

                if (string.IsNullOrWhiteSpace(hfSelectedDesigner.Value))
                {
                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "notFindDesigner", "alert('" + LocalizeString("errmsg_DesignerMissing") + "');", true);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtBookingEndDate.Text))
                {
                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "alertNull", "alert('" + LocalizeString("errBookingDateEndNull") + "');", true);
                    return;
                }

                if (cblDay.SelectedItem == null)
                {
                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "alertCblNull", "alert('" + LocalizeString("errCblNull") + "');", true);
                    return;
                }

                int startDate_Year = Convert.ToInt32(txtBookingStartDate.Text.Trim().Split('-')[0]);
                int startDate_Month = Convert.ToInt32(txtBookingStartDate.Text.Trim().Split('-')[1]);
                int startDate_Day = Convert.ToInt32(txtBookingStartDate.Text.Trim().Split('-')[2]);
                int endDate_Year = Convert.ToInt32(txtBookingEndDate.Text.Trim().Split('-')[0]);
                int endDate_Month = Convert.ToInt32(txtBookingEndDate.Text.Trim().Split('-')[1]);
                int endDate_Day = Convert.ToInt32(txtBookingEndDate.Text.Trim().Split('-')[2]);

                int startTime_Hour = txtBookingStartTime.Text.Trim().Split(' ')[1].ToUpper().Trim().Equals("PM") ? Convert.ToInt32(txtBookingStartTime.Text.Trim().Split(':')[0]) + 12 : Convert.ToInt32(txtBookingStartTime.Text.Trim().Split(':')[0]);
                int startTime_Minute = Convert.ToInt32(txtBookingStartTime.Text.Trim().Split(':')[1].Substring(0, 2));
                int endTime_Hour = txtBookingEndTime.Text.Trim().Split(' ')[1].ToUpper().Trim().Equals("PM") ? Convert.ToInt32(txtBookingEndTime.Text.Trim().Split(':')[0]) + 12 : Convert.ToInt32(txtBookingEndTime.Text.Trim().Split(':')[0]);
                int endTime_Minute = Convert.ToInt32(txtBookingEndTime.Text.Trim().Split(':')[1].Substring(0, 2));

                bool isOverlap = false;
                int overlapCount = 0;
                List<string> str_list = new List<string>();

                List<AssignedSchedule> assignedData_List = new List<AssignedSchedule>();
                List<int> selectedDays = new List<int>();

                DateTime StartDateTime = new DateTime(startDate_Year, startDate_Month, startDate_Day, startTime_Hour, startTime_Minute, 0);
                DateTime EndDateTime = new DateTime(endDate_Year, endDate_Month, endDate_Day, endTime_Hour, endTime_Minute, 0);

                //Temp Date value for looping
                DateTime StartDateTime_temp = StartDateTime;
                DateTime EndDateTime_temp = new DateTime(startDate_Year, startDate_Month, startDate_Day, endTime_Hour, endTime_Minute, 0);                

                foreach (ListItem li in cblDay.Items)   
                    if (li.Selected)             
                    selectedDays.Add(Convert.ToInt32(li.Value));

                while (DateTime.Compare(StartDateTime_temp, EndDateTime) < 0)
                {
                    bool sameWeekDay = false;                    

                    foreach (int dayOfWeek in selectedDays)
                    {
                        if (Convert.ToInt32(StartDateTime_temp.DayOfWeek) == dayOfWeek)
                        {
                            sameWeekDay = true;
                            break;
                        }
                    }

                    if (sameWeekDay)
                    {
                        AssignedSchedule assignedData = new AssignedSchedule();
                        assignedData.DesignerID = Convert.ToInt32(txtDesigner.Text);
                        assignedData.ProjectID = ProjectId;
                        assignedData.start = StartDateTime_temp;
                        assignedData.end = EndDateTime_temp;
                        assignedData.CreateByUserID = UserId;
                        
                        var validOverlap = ViewAssignedDesignerCtl.validOverlap(assignedData.DesignerID, StartDateTime_temp, EndDateTime_temp, assignedData.ProjectID);

                        if (validOverlap.Count() > 0)
                        {                            
                            foreach (var overlap in validOverlap)
                                str_list.Add(overlap.start.ToString("yyyy-MM-dd hh:mm tt") + " - " + overlap.end.ToString("yyyy-MM-dd hh:mm tt") + "\\n" + overlap.ProjectCode + "\\r\\n");

                            isOverlap = true;
                            overlapCount++;
                        }
                        assignedData_List.Add(assignedData);                        
                    }

                    StartDateTime_temp = StartDateTime_temp.AddDays(1);
                    EndDateTime_temp = EndDateTime_temp.AddDays(1);

                }

                if (isOverlap)
                {
                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "alertColiding", string.Format(LocalizeString("errCollidingDate"), overlapCount, string.Join(string.Empty, str_list)), true);
                    return;
                }
                else
                {
                    foreach (AssignedSchedule ad in assignedData_List)
                        assignedDataCtl.CreateBooking(ad);

                    var designer = ViewAssignedDesignerCtl.GetAssignedDesigner(assignedData_List.First().id);
                    sendRegularNoticeMail("N", designer, selectedDays, StartDateTime.ToString("dd-MM-yyyy"), EndDateTime.ToString("dd-MM-yyyy"));
                }  
                
                #endregion
            }
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL());
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            BookingDataController bdCtl = new BookingDataController();
            bdCtl.DeleteBooking(BookingID);
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL());
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL());
        }

        protected void sendRegularNoticeMail(string action, ViewAssignedDesigner AssignedDesigner, List<int> selectedWeekDay, string startDate, string endDate)
        {
            ViewUserPositionControl ViewUserPositionCtl = new ViewUserPositionControl();
            StringBuilder mailTo = new StringBuilder();
            mailTo.Append(AssignedDesigner.email);
            
            string mailSubject = string.Format(Localization.GetString("mailSubject", LocalResourceFile), Localization.GetString("mailBody_Assigned", LocalResourceFile), AssignedDesigner.ProjectCode);
            string mailCSS = "<style type='text/css'>a.AcceptAction{color:darkgreen;padding:6px;}a.RejectAction{color:red;padding:6px;}</style>";
            string mailBody_weekDay = string.Empty;

            var startTime = Convert.ToInt32(AssignedDesigner.startTime.Split(':')[0]) > 12 ? +
                (Convert.ToInt32(AssignedDesigner.startTime.Split(':')[0]) - 12) + ":" + AssignedDesigner.startTime.Split(':')[1] + ":" + "PM" : +
                (Convert.ToInt32(AssignedDesigner.startTime.Split(':')[0])) + ":" + AssignedDesigner.startTime.Split(':')[1] + ":" + "AM";

            var endTime = Convert.ToInt32(AssignedDesigner.endTime.Split(':')[0]) > 12 ? +
                (Convert.ToInt32(AssignedDesigner.endTime.Split(':')[0]) - 12) + ":" + AssignedDesigner.endTime.Split(':')[1] + ":" + "PM" : +
                (Convert.ToInt32(AssignedDesigner.endTime.Split(':')[0])) + ":" + AssignedDesigner.endTime.Split(':')[1] + ":" + "AM";


            foreach (int i in selectedWeekDay)
            {
                if (!string.IsNullOrWhiteSpace(mailBody_weekDay))
                    mailBody_weekDay += ", ";
                switch (i) {
                    case 0: mailBody_weekDay += "Sunday"; break;
                    case 1: mailBody_weekDay += "Monday"; break;
                    case 2: mailBody_weekDay += "Tuesday"; break;
                    case 3: mailBody_weekDay += "Wednesday"; break;
                    case 4: mailBody_weekDay += "Thursday"; break;
                    case 5: mailBody_weekDay += "Friday"; break;
                    case 6: mailBody_weekDay += "Saturday"; break;
                }
            }
            
            var projCtl = new ProjectControl();
            var projInst = projCtl.GetProjectByID(AssignedDesigner.ProjectID);
            var projTypeCtl = new ProjectTypeControl();
            var ppp = projInst.Count() == 1 ? projInst.FirstOrDefault() : null;
            StringBuilder mailBody = new StringBuilder();
            mailBody.Append(mailCSS);
            if (ppp != null)
            {
                string str00 = AssignedDesigner.DisplayName;
                string str01 = startDate;
                string str02 = endDate;
                string str03 = startTime;
                string str04 = endTime;
                string str05 = mailBody_weekDay;
                string str06 = AssignedDesigner.ProjectCode;
                string str07 = AssignedDesigner.CreatedByDisplayName;
                string str08 = ppp.Code;
                string str09 = new ProjectTypeControl().GetProjectTypeByType(ppp.Type.ToString()).TypeDesc;
                //string str10 = ppp.Name;
                string str10 = "Proj Name Error";
                DateTime str11 = ppp.Deadline;
                string str12 = ppp.Client;
                string str13 = ppp.ShowName;
                DateTime str14 = ppp.ShowDateFrom;
                DateTime str21 = ppp.ShowDateTo;
                string str15 = ppp.Venue;
                string str16 = ppp.Size;
                string str17 = ppp.Location;
                double str18 = ppp.Amount;
                string str19 = ppp.Scope;
                string str20 = ppp.Remark;
                mailBody.Append(string.Format(Localization.GetString("mailBody_Regular", LocalResourceFile), new string[] {
                    str00 != null ? str00 : string.Empty,
                    str01 != null ? str01 : string.Empty,
                    str02 != null ? str02 : string.Empty,
                    str03 != null ? str03 : string.Empty,
                    str04 != null ? str04 : string.Empty,
                    str05 != null ? str05 : string.Empty,
                    str06 != null ? str06 : string.Empty,
                    str07 != null ? str07 : string.Empty,
                    str08 != null ? str08 : string.Empty,
                    str09 != null ? str09 : string.Empty,
                    str10 != null ? str10 : string.Empty,
                    str11 != null ? str11.ToString("yyyy-MM-dd") : string.Empty,
                    str12 != null ? str12 : string.Empty,
                    str13 != null ? str13 : string.Empty,
                    str14 != null ? str14.ToString("yyyy-MM-dd") : string.Empty,
                    str21 != null ? str21.ToString("yyyy-MM-dd") : string.Empty,
                    str15 != null ? str15 : string.Empty,
                    str16 != null ? str16 : string.Empty,
                    str17 != null ? str17 : string.Empty,
                    str18.ToString(),
                    str19 != null ? str19 : string.Empty,
                    str20 != null ? str20 : string.Empty
                
                }));
            }
            SendMail(mailTo.ToString(), string.Empty, string.Empty, mailSubject, mailBody.ToString());
        }

        protected void sendNoticeMail(string action, ViewAssignedDesigner AssignedDesigner)
        {
            ViewUserPositionControl ViewUserPositionCtl = new ViewUserPositionControl();
            StringBuilder mailTo = new StringBuilder();
            mailTo.Append(AssignedDesigner.email);

            string mailBodyAction = action.Equals("N") ? Localization.GetString("mailBody_Assigned", LocalResourceFile) : action.Equals("U") ? Localization.GetString("mailBody_Updated", LocalResourceFile) : string.Empty;            
            string mailSubject = string.Format(Localization.GetString("mailSubject", LocalResourceFile), mailBodyAction, AssignedDesigner.ProjectCode);
            string mailCSS = "<style type='text/css'>a.AcceptAction{color:darkgreen;padding:6px;}a.RejectAction{color:red;padding:6px;}</style>";
            var startTime = Convert.ToInt32(AssignedDesigner.startTime.Split(':')[0]) > 12 ? +
                (Convert.ToInt32(AssignedDesigner.startTime.Split(':')[0]) - 12) + ":" + AssignedDesigner.startTime.Split(':')[1] + ":" + "PM" : +
                (Convert.ToInt32(AssignedDesigner.startTime.Split(':')[0])) + ":" + AssignedDesigner.startTime.Split(':')[1] + ":" + "AM";

            var endTime = Convert.ToInt32(AssignedDesigner.endTime.Split(':')[0]) > 12 ? +
                (Convert.ToInt32(AssignedDesigner.endTime.Split(':')[0]) - 12) + ":" + AssignedDesigner.endTime.Split(':')[1] + ":" + "PM" : +
                (Convert.ToInt32(AssignedDesigner.endTime.Split(':')[0])) + ":" + AssignedDesigner.endTime.Split(':')[1] + ":" + "AM";

            var projCtl = new ProjectControl();
            var projInst = projCtl.GetProjectByID(AssignedDesigner.ProjectID);
            var projTypeCtl = new ProjectTypeControl();
            var ppp = projInst.Count() == 1 ? projInst.FirstOrDefault() : null;
            StringBuilder mailBody = new StringBuilder();
            mailBody.Append(mailCSS);
            if (ppp != null)
            {
                string str00 = AssignedDesigner.DisplayName;
                string str01 = mailBodyAction;
                string str02 = startTime;
                string str03 = endTime;
                string str04 = AssignedDesigner.startDate;
                string str05 = AssignedDesigner.ProjectCode;
                string str06 = AssignedDesigner.CreatedByDisplayName;
                string str07 = ppp.Code;
                string str08 = projTypeCtl.GetProjectTypeByType(ppp.Type.ToString()).TypeDesc;
                //string str09 = ppp.Name;
                string str09 = "Proj Name Error";
                DateTime str10 = ppp.Deadline;
                string str11 = ppp.Client;
                string str12 = ppp.ShowName;
                DateTime str13 = ppp.ShowDateFrom;
                DateTime str20 = ppp.ShowDateTo;
                string str14 = ppp.Venue;
                string str15 = ppp.Size;
                string str16 = ppp.Location;
                double str17 = ppp.Amount;
                string str18 = ppp.Scope;
                string str19 = ppp.Remark;

                mailBody.Append(string.Format(Localization.GetString("mailBody", LocalResourceFile), new string[] {
                    str00 != null ? str00 : string.Empty,
                    str01 != null ? str01 : string.Empty,
                    str02 != null ? str02 : string.Empty,
                    str03 != null ? str03 : string.Empty,
                    str04 != null ? str04 : string.Empty,
                    str05 != null ? str05 : string.Empty,
                    str06 != null ? str06 : string.Empty,
                    str07 != null ? str07 : string.Empty,
                    str08 != null ? str08 : string.Empty,
                    str09 != null ? str09 : string.Empty,
                    str10 != null ? str10.ToString("yyyy-MM-dd") : string.Empty,
                    str11 != null ? str11 : string.Empty,
                    str12 != null ? str12 : string.Empty,
                    str13 != null ? str13.ToString("yyyy-MM-dd") : string.Empty,
                    str20 != null ? str20.ToString("yyyy-MM-dd") : string.Empty,
                    str14 != null ? str14 : string.Empty,//14
                    str15 != null ? str15 : string.Empty,
                    str16 != null ? str16 : string.Empty,
                    str17.ToString(),
                    str18 != null ? str18 : string.Empty,
                    str19 != null ? str19 : string.Empty//19
                }));
            }
            SendMail(mailTo.ToString(), string.Empty, string.Empty, mailSubject, mailBody.ToString());
        }
    }
}