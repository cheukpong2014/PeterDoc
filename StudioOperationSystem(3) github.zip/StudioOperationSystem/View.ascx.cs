﻿/*
' Copyright (c) 2016  Milton-Exhibits
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using System;
using System.Web.UI.WebControls;
using Milton.Modules.StudioOperationSystem.Components;
using DotNetNuke.Security;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Services.Localization;
using DotNetNuke.UI.Utilities;
using System.Linq;
using System.Collections.Generic;
using DotNetNuke.Entities.Users;
using System.Drawing;

namespace Milton.Modules.StudioOperationSystem
{
    /// -----------------------------------------------------------------------------
    /// <summary>
    /// The View class displays the content
    /// 
    /// Typically your view control would be used to display content or functionality in your module.
    /// 
    /// View may be the only control you have in your project depending on the complexity of your module
    /// 
    /// Because the control inherits from StudioOperationSystemModuleBase you have access to any custom properties
    /// defined there, as well as properties from DNN such as PortalId, ModuleId, TabId, UserId and many more.
    /// 
    /// </summary>
    /// -----------------------------------------------------------------------------
    public partial class View : StudioOperationSystemModuleBase, IActionable
    {
        protected void Page_Load(object sender, EventArgs e)
        {            
            try
            {
                if (!IsPostBack)
                {
                    UserPositionControl UserPositionCtl = new UserPositionControl();
                    UserPosition UserPosition = UserPositionCtl.GetUserPosition(UserId);
                    ProjectControl ProjectCtl = new ProjectControl();
                    ViewProjectByDesignerControl assignedDataCtl = new ViewProjectByDesignerControl();
                    var DesignerCtl = new TeamMemberController();

                    if (UserPosition != null)
                    {
                        if (UserPosition.isSuperUser.Equals("Y"))                    
                            hfIsSuperUser.Value = "Y";
                        else
                            hfIsSuperUser.Value = "N";

                        hfUserPosition.Value = UserPosition.Position;
                    }

                    //Superuser or Team Lead
                    if (hfIsSuperUser.Value.Equals("Y") || hfUserPosition.Value.Equals("TL"))
                    {
                        ProjectBar.Visible = false;
                        ProjectDropDown.Visible = true;

                        var project = ProjectCtl.GetProjectsByTeamLeads();
                        if (project != null && project.Count() > 0)
                        {

                            ddlProjects.DataSource = project;
                            ddlProjects.DataValueField = "ID";
                            ddlProjects.DataTextField = "Code";
                            ddlProjects.DataBind();
                        }
                    }
                    //Project Sales
                    else if (hfUserPosition.Value.Equals("PS"))
                    {
                        ProjectDropDown.Visible = false;

                        var project = ProjectCtl.GetProjectsByProjectSales(UserId);
                        if (project != null && project.Count() > 0)
                        {
                            rptProject.DataSource = from pt in project
                                                    select new
                                                    {
                                                        ShowName = pt.Code,
                                                        id = pt.ID,
                                                        color = pt.Color,
                                                        fontColor = "rgb(" + 
                                                                    Color.FromArgb(ColorTranslator.FromHtml(pt.Color).ToArgb() ^ 0xffffff).R + ", " +
                                                                    Color.FromArgb(ColorTranslator.FromHtml(pt.Color).ToArgb() ^ 0xffffff).G + ", " +
                                                                    Color.FromArgb(ColorTranslator.FromHtml(pt.Color).ToArgb() ^ 0xffffff).B + ")"
                                                    };

                            rptProject.DataBind();
                        }
                        else
                            ProjectBar.Visible = false;

                        btnDesigner.Visible = false;
                        btnProject.Visible = true;
                    }                    
                    else if (string.IsNullOrWhiteSpace(hfUserPosition.Value))
                    {

                        

                        var designer = DesignerCtl.GetActiveDesigner(UserId);

                        //Designer
                        if (designer.Count() > 0)
                        {
                            ProjectDropDown.Visible = false;
                            var project = assignedDataCtl.GetProjectByDesigner(UserId);
                            if (project != null && project.Count() > 0)
                            {
                                rptProject.DataSource = from pt in project
                                                        select new
                                                        {
                                                            ShowName = pt.ProjectCode,
                                                            id = pt.ProjectID,
                                                            color = pt.Color,
                                                            fontColor = "rgb(" +
                                                                    Color.FromArgb(ColorTranslator.FromHtml(pt.Color).ToArgb() ^ 0xffffff).R + ", " +
                                                                    Color.FromArgb(ColorTranslator.FromHtml(pt.Color).ToArgb() ^ 0xffffff).G + ", " +
                                                                    Color.FromArgb(ColorTranslator.FromHtml(pt.Color).ToArgb() ^ 0xffffff).B + ")"
                                                        };
                                /*
                                 * 
                                 *                             rColor.BackColor = ColorTranslator.FromHtml(project.Color);
                            rColor.ForeColor = Color.FromArgb(rColor.BackColor.ToArgb() ^ 0xffffff);
                                 * 
                                 * 
                                 * */
                                rptProject.DataBind();
                                btnProjectTimer.Visible = true;
                            }
                            else
                                ProjectBar.Visible = false;

                            btnDesigner.Visible = false;
                            btnProject.Visible = false;
                        }
                        else
                        //Not registered staff
                        {
                            pnlView.Visible = false;
                            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "AccessDenied", "alert('" + LocalizeString("errmsg_AccessDenied") + "');", true);
                            return;
                        }


                    }                    
                }
            }
            catch (Exception exc) //Module failed to load
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        public ModuleActionCollection ModuleActions
        {
            get
            {
                var actions = new ModuleActionCollection
                    {
                        {
                            GetNextActionID(), Localization.GetString("EditModule", LocalResourceFile), "", "", "",
                            EditUrl(), false, SecurityAccessLevel.Edit, true, false
                        }
                    };
                return actions;
            }
        }

        protected void btnGoToProject(object sender, EventArgs e)
        {
            Response.Redirect(EditUrl("ProjectView"));
        }

        protected void btnDesigner_Click(object sender, EventArgs e)
        {
            Response.Redirect(EditUrl("DesignerView"));
        }
    }
}

public class AssignedData
{
    public int ProjectID { get; set; }
}