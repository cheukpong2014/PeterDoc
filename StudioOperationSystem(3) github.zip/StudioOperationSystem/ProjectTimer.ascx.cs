﻿using Milton.Modules.StudioOperationSystem.Components;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Milton.Modules.StudioOperationSystem
{
    public partial class ProjectTimer : StudioOperationSystemModuleBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            ViewProjectByDesignerControl assignedDataCtl = new ViewProjectByDesignerControl();
            if (!IsPostBack)
            {
                hfIsDisabledStartButton.Value = "Y";

                IEnumerable<ViewProjectByDesigner> project = assignedDataCtl.GetProjectByDesigner(UserId);
                if (project != null && project.Count() > 0)
                {
                    rptProject.DataSource = from pt in project
                                            select new
                                            {
                                                ShowName = pt.ProjectCode,
                                                id = pt.ProjectID,
                                                color = pt.Color,
                                                fontColor = "rgb(" +
                                                        Color.FromArgb(ColorTranslator.FromHtml(pt.Color).ToArgb() ^ 0xffffff).R + ", " +
                                                        Color.FromArgb(ColorTranslator.FromHtml(pt.Color).ToArgb() ^ 0xffffff).G + ", " +
                                                        Color.FromArgb(ColorTranslator.FromHtml(pt.Color).ToArgb() ^ 0xffffff).B + ")"
                                            };

                    rptProject.DataBind();
                }
                else
                    ProjectList.Visible = false;

            }
                
        }
    }
}