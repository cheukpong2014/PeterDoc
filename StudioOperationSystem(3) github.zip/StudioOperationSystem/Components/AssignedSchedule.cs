﻿using System;
using System.Web.Caching;
using DotNetNuke.Common.Utilities;
using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Entities.Content;
using System.Collections.Generic;
using DotNetNuke.Data;
using System.Linq;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("StudioOperationSystem_AssignedSchedule")]
    [PrimaryKey("ID", AutoIncrement = true)]
    public class AssignedSchedule
    {
        public int id { get; set; }
        public int DesignerID { get; set; }
        public int ProjectID { get; set; }
        public DateTime start { get; set; }
        public DateTime end { get; set; }
        public int CreateByUserID { get; set; }
    }
    public class BookingDataController
    {
        public void CreateBooking(AssignedSchedule t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<AssignedSchedule>();
                rep.Insert(t);
            }
        }
        public void DeleteBooking(int eventID)
        {
            var t = GetBooking(eventID);
            DeleteBooking(t);
        }
        public void DeleteBooking(AssignedSchedule t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<AssignedSchedule>();
                rep.Delete(t);
            }
        }
        public AssignedSchedule GetBooking(int eventID)
        {
            AssignedSchedule t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<AssignedSchedule>();
                t = rep.GetById(eventID);
            }
            return t;
        }
        public IEnumerable<AssignedSchedule> GetBookings()
        {
            IEnumerable<AssignedSchedule> t = null;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<AssignedSchedule>();
                t = rep.Get();
            }
            return t;
        }
        public IEnumerable<AssignedSchedule> GetBookingByDesignerId(int DesignerId)
        {
            IEnumerable<AssignedSchedule> t = null;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<AssignedSchedule>();
                t = rep.Find("where DesignerID=@0", DesignerId);
            }
            return t;
        }
        public IEnumerable<AssignedSchedule> GetBookingByProjectId(int ProjectId)
        {
            IEnumerable<AssignedSchedule> t = null;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<AssignedSchedule>();
                t = rep.Find("where ProjectID=@0", ProjectId);
            }
            return t;
        }
        public IEnumerable<AssignedSchedule> GetBookingByProjectIdandDate(int ProjectId, DateTime end)
        {
            IEnumerable<AssignedSchedule> t = null;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<AssignedSchedule>();
                t = rep.Find("where ProjectID=@0 and ([start] > @1 or end between [start] and [end])", ProjectId, end);
            }
            return t;
        }
        public void UpdateBooking(AssignedSchedule t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<AssignedSchedule>();
                rep.Update(t);
            }
        }
    }
}