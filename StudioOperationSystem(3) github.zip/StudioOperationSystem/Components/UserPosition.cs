﻿using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("StudioOperationSystem_UserPosition")]
    //setup the primary key for table
    [PrimaryKey("UserId", AutoIncrement = false)]
    //scope the objects to the ModuleId of a module on a page (or copy of a module on a page)

    public class UserPosition
    {
        public int UserId { get; set; }
        public string isSuperUser { get; set; }
        public string Position { get; set; }
    }

    public class UserPositionControl
    {
        public void CreateUserPosition(UserPosition up)
        {
            using (IDataContext ctx = DataContext.Instance()) {
                var rep = ctx.GetRepository<UserPosition>();
                rep.Insert(up);
            }
        }
        
        public void DeleteUserPosition(int UserId)
        {
            var t = GetUserPosition(UserId);
            DeleteUserPosition(t);
        }

        public UserPosition GetUserPosition(int UserId)
        {
            IEnumerable<UserPosition> t;
            using(IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<UserPosition>();
                t = rep.Find("where UserId=@0", UserId);
            }

            return t.Count() > 0? t.First():null;
            
        }    

        public IEnumerable<UserPosition> GetUserPositions()
        {
            IEnumerable<UserPosition> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<UserPosition>();
                t = rep.Get();
            }
            if (t == null)
                return null;
            return t;
        }

        public void UpdateUserPosition(UserPosition up)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<UserPosition>();
                rep.Update(up);
            }
        }

        public void DeleteUserPosition(UserPosition up)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<UserPosition>();
                rep.Delete(up);
            }
        }

    }
}