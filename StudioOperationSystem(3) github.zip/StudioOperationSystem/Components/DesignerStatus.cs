﻿/*
' Copyright (c) 2016 Milton-Exhibits
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System.Collections.Generic;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("StudioOperationSystem_DesignerStatus")]
    //setup the primary key for table
    [PrimaryKey("StatusID", AutoIncrement = false)]
    //configure caching using PetaPoco
    public class DesignerStatus
    {
        public int StatusID { get; set; }
        public string StatusDescription { get; set; }
    }

    public class DesignerStatusController
    {
        //public IEnumerable<DesignerStatus> GetStatusDescription(int StatusID)
        //{
        //    IEnumerable<DesignerStatus> t;
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<DesignerStatus>();
        //        t = rep.Find(" where StatusID = @0 ", StatusID);
        //    }
        //    return t;
        //}
    }
}