﻿using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System.Collections.Generic;
using System.Linq;


namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("StudioOperationSystem_ProjectStatus")]
    //setup the primary key for table
    [PrimaryKey("ID", AutoIncrement = false)]
    //scope the objects to the ModuleId of a module on a page (or copy of a module on a page)
    public class ProjectStatus
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string isDisplay { get; set; }
    }

    public class ProjectStatusControl
    {
        public void CreateStatus(ProjectStatus t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectStatus>();
                rep.Insert(t);
            }
        }

        public void DeleteStatus(int Id)
        {
            var t = GetStatus(Id);
            DeleteStatus(t);
        }

        public void DeleteStatus(ProjectStatus t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectStatus>();
                rep.Delete(t);
            }
        }

        public IEnumerable<ProjectStatus> GetStatuss()
        {
            IEnumerable<ProjectStatus> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectStatus>();
                t = rep.Get();
            }
            return t;
        }

        public IEnumerable<ProjectStatus> GetDisplayStatus()
        {
            IEnumerable<ProjectStatus> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectStatus>();
                t = rep.Find(" where isDisplay = 'Y'");
            }
            return t;
        }

        public ProjectStatus GetStatus(int Id)
        {
            ProjectStatus t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectStatus>();
                t = rep.GetById(Id);
            }
            return t;
        }

        public void UpdateStatus(ProjectStatus t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectStatus>();
                rep.Update(t);
            }
        }
    }
}