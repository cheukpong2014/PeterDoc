﻿using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("StudioOperationSystem_DesignerTimer")]
    //setup the primary key for table
    [PrimaryKey("ID", AutoIncrement = true)]
    public class DesignerTimer
    {
        public int ID { get; set; }
        public int DesignerID { get;set;}
        public int ProjectID  {get;set;}
        public DateTime ActionTime {get;set;}
        public string ActionType { get; set; }
    }

    public class DesignerTimerController
    {
        public void CreateDesignerTimer(DesignerTimer t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<DesignerTimer>();
                rep.Insert(t);
            }
        }

        public void DeleteDesignerTimer(DesignerTimer t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<DesignerTimer>();
                rep.Delete(t);
            }
        }

        public void UpdateDesignerTimer(DesignerTimer t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<DesignerTimer>();
                rep.Update(t);
            }
        }

        public IEnumerable<DesignerTimer> GetDesignerTimer(int designerID, int projectID)
        {
            IEnumerable<DesignerTimer> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<DesignerTimer>();
                t = rep.Find(" where DesignerID = @0 and ProjectID = @1", designerID, projectID);
            }
            return t;
        }

        public IEnumerable<DesignerTimer> GetDesignerStartedTimer(int designerID, int projectID)
        {
            IEnumerable<DesignerTimer> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<DesignerTimer>();
                t = rep.Find(" where ActionType = 'S' and DesignerID = @0 and ProjectID = @1", designerID, projectID);
            }
            return t;
        }
    }
}