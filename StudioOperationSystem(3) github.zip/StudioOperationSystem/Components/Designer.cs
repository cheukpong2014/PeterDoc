﻿/*
' Copyright (c) 2016 Milton-Exhibits
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using System;
using System.Web.Caching;
using DotNetNuke.Common.Utilities;
using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Entities.Content;
using System.Collections.Generic;
using DotNetNuke.Data;
using System.Linq;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("StudioOperationSystem_Designer")]
    //setup the primary key for table
    [PrimaryKey("ID", AutoIncrement = true)]
    //configure caching using PetaPoco
    public class Designer
    {
        public int ID { get; set;}
        public int UserId { get; set; }
        public int JobLevel { get; set; }
        public double HourlyRate { get; set; }
        public string Remark { get; set; }
        public int Status { get; set; }
        public DateTime CreatedDate { get; set; }
        public int CreatedBy { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateBy { get; set; }
    }

    public class DesignerController
    {
        //public void CreateDesigner(Designer t)
        //{
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<Designer>();
        //        rep.Insert(t);
        //    }
        //}

        //public void DeleteDesigner(int DesignerId)
        //{
        //    var t = GetDesigner(DesignerId);
        //    DeleteDesigner(t);
        //}

        //public void DeleteDesigner(Designer t)
        //{
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<Designer>();
        //        rep.Delete(t);
        //    }
        //}

        //public IEnumerable<Designer> GetDesigners()
        //{
        //    IEnumerable<Designer> t;
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<Designer>();
        //        t = rep.Get();
        //    }
        //    return t;
        //}

        //public IEnumerable<Designer> GetPendingDesigner(int ID)
        //{
        //    IEnumerable<Designer> t;
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<Designer>();
        //        t = rep.Find("where (status = 0 or status = 2) and ID=@0", ID);
        //    }
        //    return t;
        //}

        //public IEnumerable<Designer> GetActiveDesigner(int ID)
        //{
        //    IEnumerable<Designer> t;
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<Designer>();
        //        t = rep.Find(" where UserId=@0 and Status=1 ", ID);
        //    }
        //    return t;
        //}

        //public IEnumerable<Designer> GetActiveDesigners()
        //{
        //    IEnumerable<Designer> t;
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<Designer>();
        //        t = rep.Find(" where status=1 ");
        //    }
        //    return t;
        //}

        //public IEnumerable<Designer> GetExistingDesigners()
        //{
        //    IEnumerable<Designer> t;
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<Designer>();
        //        t = rep.Find(" where status >=0 and status < 3 ");
        //    }
        //    return t;
        //}

        //public bool IsDesignerExist(int designerID)
        //{
        //    bool result = true;
        //    IEnumerable<Designer> t;
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<Designer>();
        //        t = rep.Find(" where UserID=@0 and status >=0 and status < 3 ", designerID);
        //    }
            
        //    if (t.Count() <= 0)
        //        result = false;

        //    return result;
        //}

        //public Designer GetDesigner(int ID)
        //{
        //    Designer t;
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<Designer>();
        //        t = rep.GetById(ID);
        //    }
        //    return t;
        //}

        //public void UpdateDesigner(Designer t)
        //{
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<Designer>();
        //        rep.Update(t);
        //    }
        //}

    }

}
