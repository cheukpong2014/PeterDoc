﻿
using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System.Collections.Generic;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("StudioOperationSystem_TeamMemberStatus")]
    [PrimaryKey("StatusID", AutoIncrement = false)]
    public class TeamMemberStatus
    {
        public int StatusID { get; set; }
        public string StatusDescription { get; set; }
    }

    public class TeamMemberStatusController
    {
        public IEnumerable<TeamMemberStatus> GetStatusDescription(int StatusID)
        {
            IEnumerable<TeamMemberStatus> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMemberStatus>();
                t = rep.Find(" where StatusID = @0 ", StatusID);
            }
            return t;
        }
    }
}