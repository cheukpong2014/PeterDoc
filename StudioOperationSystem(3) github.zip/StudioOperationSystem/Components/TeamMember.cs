﻿using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("StudioOperationSystem_TeamMember")]
    [PrimaryKey("ID", AutoIncrement = true)]
    public class TeamMember
    {
        public int ID { get; set; }
        public int TeamID { get; set; }
        public int StaffID { get; set; }
        public string isManager { get; set; }
        public string isTeamLeader { get; set; }
        public string isDesigner { get; set; }
        public string isProjectSales { get; set; }
        public int JobLevel { get; set; }
        public double HourlyRate { get; set; }
        public string Remark { get; set; }
        public int Status { get; set; }
        public DateTime CreateDate { get; set; }
        public int CreatedBy { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdatedBy { get; set; }
    }
    public class TeamMemberController
    {
        //create
        public TeamMember CreateTeamMember(TeamMember t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMember>();
                rep.Insert(t);
            }
            return t;
        }
        //update
        public TeamMember UpdateTeamMember(TeamMember t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMember>();
                rep.Update(t);
            }
            return t;
        }
        //delete
        public void DeleteTeamMemberByID(int ID)
        {
            var t = GetTeamMemberByStaffID(ID);
            //DeleteTeamMember(t.First());
            DeleteTeamMember(ID);
        }
        public void DeleteTeamMember(int id)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMember>();
                rep.Delete("where ID = @0", id);
                //rep.Delete(t);
            }
        }
        //get
        public IEnumerable<TeamMember> GetTeamMembers()
        {
            IEnumerable<TeamMember> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMember>();
                t = rep.Get();
            }
            return t;
        }
        //get by sql
        public IEnumerable<TeamMember2> GetTeamMemberByID(int ID)
        {
            using (IDataContext db = DataContext.Instance())
            {
                return db.ExecuteQuery<TeamMember2>(System.Data.CommandType.Text, "select u1.DisplayName,s1.*, t1.StatusDescription from StudioOperationSystem_TeamMember s1 left join users u1 on s1.StaffID = u1.UserID left join StudioOperationSystem_TeamMemberStatus t1 on s1.Status = t1.StatusID where ID = " + ID);
            }
        }
        //get by sql
        public IEnumerable<TeamMember> GetTeamMemberByStaffID(int StaffID)
        {
            IEnumerable<TeamMember> t;
            using (IDataContext context = DataContext.Instance())
            {
                var rep = context.GetRepository<TeamMember>();
                t = rep.Find("where StaffID = @0", StaffID);
            }
            return t;
        }
        //get by sql
        //public IEnumerable<sp_ClaimFormDetails> GetTeamMembersBySQL()
        //{
        //    using (IDataContext db = DataContext.Instance())
        //    {
        //        return db.ExecuteQuery<sp_ClaimFormDetails>(System.Data.CommandType.Text, "");
        //    }
        //}
        //get by sql
        public IEnumerable<distinctTeamID> GetDistinctTeam(int StaffID)
        {
            using (IDataContext db = DataContext.Instance())
            {
                return db.ExecuteQuery<distinctTeamID>(System.Data.CommandType.Text, "select Distinct TeamID from StudioOperationSystem_TeamMember where StaffID = " + StaffID);
            }
        }
        public IEnumerable<TeamMember2> GetTeamMemberWithLeftJoinByStaffID(int StaffID)
        {
            using (IDataContext db = DataContext.Instance())
            {
                return db.ExecuteQuery<TeamMember2>(System.Data.CommandType.Text, "select u1.DisplayName,s1.*, t1.StatusDescription from StudioOperationSystem_TeamMember s1 left join users u1 on s1.StaffID = u1.UserID left join StudioOperationSystem_TeamMemberStatus t1 on s1.Status = t1.StatusID where StaffID = " + StaffID);
            }
        }

        //***************************Change Designer TO TeamMember****************************
        public IEnumerable<TeamMember> GetExistingDesigners()
        {
            IEnumerable<TeamMember> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMember>();
                t = rep.Find("where Status >=0 and status < 3 and isDesigner = '1'");
            }
            return t;
        }
        public IEnumerable<TeamMember> GetDesigner(int ID)
        {
            IEnumerable<TeamMember> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMember>();
                t = rep.Find("where ID = @0",ID);
            }
            return t;
        }
        public TeamMember UpdateDesigner(TeamMember t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMember>();
                rep.Update(t);
            }
            return t;
        }
        public IEnumerable<TeamMember> GetActiveDesigner(int ID)
        {
            IEnumerable<TeamMember> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMember>();
                t = rep.Find(" where StaffID=@0 and Status=1 ", ID);
            }
            return t;
        }
        public IEnumerable<TeamMember> GetActiveDesigners()
        {
            IEnumerable<TeamMember> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMember>();
                t = rep.Find(" where status=1 ");
            }
            return t;
        }
        public IEnumerable<TeamMember> GetPendingDesigner(int ID)
        {
            IEnumerable<TeamMember> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMember>();
                t = rep.Find("where (status = 0 or status = 2) and ID=@0", ID);
            }
            return t;
        }
        public IEnumerable<TeamMember> IsTeamMemberExist(int TeamID, int StaffID)
        {
            IEnumerable<TeamMember> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<TeamMember>();
                t = rep.Find("where TeamID = @0 and StaffID = @1 and Status >=0 and Status < 3", TeamID, StaffID);
            }
            return t;
        }
        //***************************Change UserPosition TO TeamMember****************************
    }
    public class distinctTeamID
    {
        public int TeamID { get; set; }
    }
    public class TeamMember2
    {
        public string DisplayName { get; set; }
        public int ID { get; set; }
        public int TeamID { get; set; }
        public int StaffID { get; set; }
        public string isManager { get; set; }
        public string isTeamLeader { get; set; }
        public string isDesigner { get; set; }
        public string isProjectSales { get; set; }
        public int JobLevel { get; set; }
        public double HourlyRate { get; set; }
        public string Remark { get; set; }
        public int Status { get; set; }
        public DateTime CreateDate { get; set; }
        public int CreatedBy { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdatedBy { get; set; }
        public string StatusDescription { get; set; }
    }
}