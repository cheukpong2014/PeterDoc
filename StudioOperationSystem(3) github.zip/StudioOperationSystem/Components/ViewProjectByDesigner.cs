﻿using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("vw_SOSProjectByDesigner")]
    //setup the primary key for table
    public class ViewProjectByDesigner
    {
        public int DesignerID { get; set; }
        public int ProjectID { get; set; }
        public string ProjectCode { get; set; }
        public string ShowName { get; set; }
        public int Status { get; set; }
        public DateTime ShowDateFrom { get; set; }
        public DateTime ShowDateTo { get; set; }
        public DateTime Deadline { get; set; }
        public string Color { get; set; }
    }

    public class ViewProjectByDesignerControl
    {
        public IEnumerable<ViewProjectByDesigner> GetProjectByDesigner(int designerID)
        {
            IEnumerable<ViewProjectByDesigner> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ViewProjectByDesigner>();
                t = rep.Find("where DesignerID = @0", designerID);
            }
            return t;
        }
    }
}