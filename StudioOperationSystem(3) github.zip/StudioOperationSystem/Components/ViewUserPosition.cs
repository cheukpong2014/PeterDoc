﻿using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("vw_SOSUserPosition")]
    //setup the primary key for table
    public class ViewUserPosition
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string isSuperUser { get; set; }
        public string Position { get; set; }
        public string email { get; set; }
    }

    public class ViewUserPositionControl
    {
        public IEnumerable<ViewUserPosition> SearchTeamLeads(string q)
        {
            IEnumerable<ViewUserPosition> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ViewUserPosition>();
                t = rep.Find("where Position = 'TL' AND UserName like '%" + q + "%'");
            }
            //if (t.Count() <= 0 )
            //    return null;
            return t;
        }

        public IEnumerable<ViewUserPosition> GetSuperUsers()
        {
            IEnumerable<ViewUserPosition> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ViewUserPosition>();
                t = rep.Find("where isSuperUser = 'Y'");
            }
            //if (t.Count() <= 0 )
            //    return null;
            return t;
        }

        public IEnumerable<ViewUserPosition> GetTeamLeads()
        {
            IEnumerable<ViewUserPosition> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ViewUserPosition>();
                t = rep.Find("where isSuperUser = 'N' AND Position = 'TL' ");
            }
            //if (t.Count() <= 0 )
            //    return null;
            return t;
        }
    }
}