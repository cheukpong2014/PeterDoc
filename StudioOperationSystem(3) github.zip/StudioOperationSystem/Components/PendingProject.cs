﻿using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("StudioOperationSystem_PendingProject")]
    //setup the primary key for table
    [PrimaryKey("ID", AutoIncrement = false)]
    //scope the objects to the ModuleId of a module on a page (or copy of a module on a page)

    public class PendingProject
    {
        public int ID { get; set; }
        public string Code { get; set; }
        //public string Name { get; set; }
        public string Client { get; set; }
        public string ShowName { get; set; }
        public DateTime ShowDateFrom { get; set; }
        public DateTime ShowDateTo { get; set; }
        public DateTime Deadline { get; set; }
        public string Venue { get; set; }
        public string Location { get; set; }
        public double Amount { get; set; }
        public string Scope { get; set; }
        public string Size { get; set; }
        public int Status { get; set; }
        public string Remark { get; set; }
        public int Type { get; set; }
        public int ProjectSales { get; set; }
        public int? StudioTeamLead { get; set; }
        public string Color { get; set; }
    }

    public class PreProjectControl
    {
        public void CreateProject(PendingProject t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<PendingProject>();
                rep.Insert(t);
            }
        }

        public void DeleteProject(int Id)
        {
            var t = GetProject(Id);
            DeleteProject(t);
        }

        public void DeleteProject(PendingProject t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<PendingProject>();
                rep.Delete(t);
            }
        }

        public IEnumerable<PendingProject> GetProjects()
        {
            IEnumerable<PendingProject> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<PendingProject>();
                t = rep.Get();
            }
            return t;
        }

        //public IEnumerable<PreProject> GetProjectsByProjectSales(int CreateBy)
        //{
        //    IEnumerable<PreProject> t;
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<PreProject>();
        //        t = rep.Find("where ProjectSales=@0 and (Status  = 1 or Status = 4)", CreateBy);
        //    }
        //    return t;
        //}

        public PendingProject GetProject(int Id)
        {
            PendingProject t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<PendingProject>();
                t = rep.GetById(Id);
            }
            return t;
        }

        public void UpdateProject(PendingProject t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<PendingProject>();
                rep.Update(t);
            }
        }

    }
}