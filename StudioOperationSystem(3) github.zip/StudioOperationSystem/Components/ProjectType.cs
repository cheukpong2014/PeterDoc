﻿using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("StudioOperationSystem_ProjectType")]
    [PrimaryKey("ID", AutoIncrement = true)]
    public class ProjectType
    {
        public int ID { get; set; }
        public string TypeDesc { get; set; }
    }

    public class ProjectTypeControl
    {
        public void CreateProjectType(ProjectType t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectType>();
                rep.Insert(t);
            }
        }

        public void DeleteProjectType(int Id)
        {
            var t = GetProjectType(Id);
            DeleteProjectType(t);
        }

        public void DeleteProjectType(ProjectType t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectType>();
                rep.Delete(t);
            }
        }

        public ProjectType GetProjectType(int Id)
        {
            ProjectType t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectType>();
                t = rep.GetById(Id);
            }
            return t;
        }

        public IEnumerable<ProjectType> GetProjectTypes()
        {
            IEnumerable<ProjectType> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectType>();
                t = rep.Get();
            }
            return t;
        }

        public ProjectType GetProjectTypeByType(string Type)
        {
            IEnumerable<ProjectType> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectType>();
                t = rep.Find("where TypeDesc = @0", Type);
            }
            return (t.Count() > 0) ? t.First() : null;
        }

        public void UpdateProjectType(ProjectType t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ProjectType>();
                rep.Update(t);
            }
        }

    }
}