﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DotNetNuke.Web.Api;

namespace Milton.Modules.StudioOperationSystem.Services
{
    public class RouteMapper : IServiceRouteMapper
    {
        public void RegisterRoutes(IMapRoute mapRouteManager)
        {
            mapRouteManager.MapHttpRoute("StudioOperationSystem", "default", "{controller}/{action}", new[] { "Milton.Modules.StudioOperationSystem.Services" });
        }
    }
}