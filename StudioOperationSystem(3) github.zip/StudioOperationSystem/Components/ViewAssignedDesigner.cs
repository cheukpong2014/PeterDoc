﻿using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("vw_SOSAssignedDesigner")]
    //setup the primary key for table
    public class ViewAssignedDesigner
    {
        public int ID { get; set; }
        public int designerID { get; set; }
        public string DisplayName { get; set; }
        public string email { get; set; }
        public int ProjectID { get; set; }
        public string ProjectCode { get; set; }
        public string startDate { get; set; }
        public string startTime { get; set; }
        public string endDate { get; set; }
        public string endTime { get; set; }
        public DateTime start { get; set; }
        public DateTime end { get; set; }
        public string CreatedByDisplayName { get; set; }
    }

    public class ViewAssignedDesignerControl
    {
        public ViewAssignedDesigner GetAssignedDesigner(int ID)
        {
            ViewAssignedDesigner t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ViewAssignedDesigner>();
                t = rep.GetById(ID);
            }
            return t;
        }

        public IEnumerable<ViewAssignedDesigner> validOverlap(int designerID, DateTime start, DateTime end, int ProjectID)
        {
            IEnumerable<ViewAssignedDesigner> t = null;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<ViewAssignedDesigner>();
                t = rep.Find(" where designerID = @0 AND (([end] < @1 and [end] > @2) or ([start] < @1 and [start] > @2)) and not ProjectID = @3", designerID, start, end, ProjectID);
            }
            return t;
        }
    }
}