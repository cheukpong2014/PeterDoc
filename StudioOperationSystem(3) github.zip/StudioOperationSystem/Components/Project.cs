﻿using DotNetNuke.ComponentModel.DataAnnotations;
using DotNetNuke.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Milton.Modules.StudioOperationSystem.Components
{
    [TableName("StudioOperationSystem_Project")]
    //setup the primary key for table
    [PrimaryKey("ID", AutoIncrement = true)]
    //scope the objects to the ModuleId of a module on a page (or copy of a module on a page)

    public class Project
    {
        public int ID { get; set; }
        public string Code { get; set; }
        //public string Name { get; set; }
        public string Client { get; set; }
        public string ShowName { get; set; }
        public DateTime ShowDateFrom { get; set; }
        public DateTime ShowDateTo { get; set; }
        public DateTime Deadline { get; set; }
        public string Venue { get; set; }
        public string Location { get; set; }
        public double Amount { get; set; }
        public string Scope { get; set; }
        public string Size { get; set; }
        public int Status { get; set; }
        public string Remark { get; set; }
        public int Type { get; set; }
        public int ProjectSales { get; set; }
        public int? StudioTeamLead { get; set; }
        public string Color { get; set; }
    }

    public class ProjectControl
    {
        public void CreateProject(Project t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<Project>();
                rep.Insert(t);
            }
        }

        public void DeleteProject(int Id)
        {
            var t = GetProject(Id);
            DeleteProject(t);
        }

        public void DeleteProject(Project t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<Project>();
                rep.Delete(t);
            }
        }

        public IEnumerable<Project> GetProjects()
        {
            IEnumerable<Project> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<Project>();
                t = rep.Get();
            }
            return t;
        }        

        public IEnumerable<Project> GetProjectsByProjectSales(int CreateBy)
        {
            IEnumerable<Project> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<Project>();
                t = rep.Find("where ProjectSales=@0 and (Status = 0 or Status = 3)", CreateBy);
            }
            return t;
        }

        public IEnumerable<Project> GetProjectsByTeamLeads()
        {
            IEnumerable<Project> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<Project>();
                t = rep.Find("where Status = 0 or Status = 3");
            }
            return t;
        }
        //public Project GetProjectByCode(String code)
        //{
        //    IEnumerable<Project> t;
        //    using (IDataContext ctx = DataContext.Instance())
        //    {
        //        var rep = ctx.GetRepository<Project>();
        //        t = rep.Find("where Code = @0", code);
        //    }
        //    if (t == null)
        //    {
        //        return null;
        //    }
        //    return t.First();
        //}

        public Project GetProject(int Id)
        {
            Project t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<Project>();
                t = rep.GetById(Id);
            }
            return t;
        }

        public void UpdateProject(Project t)
        {
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<Project>();
                rep.Update(t);
            }
        }
        public IEnumerable<Project> GetProjectByID(int id)
        {
            IEnumerable<Project> t;
            using (IDataContext ctx = DataContext.Instance())
            {
                var rep = ctx.GetRepository<Project>();
                t = rep.Find("where ID = @0", id);
            }
            return t;
        }

    }
}