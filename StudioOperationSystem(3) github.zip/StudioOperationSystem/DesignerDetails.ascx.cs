﻿using DotNetNuke.Entities.Users;
using Milton.Modules.StudioOperationSystem.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using DotNetNuke.Services.Localization;

namespace Milton.Modules.StudioOperationSystem
{
    public partial class DesignerDetails : StudioOperationSystemModuleBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var ID = Request.QueryString["ID"];

            if (!IsPostBack)
            {
                UserPositionControl upCtl = new UserPositionControl();
                UserPosition position = upCtl.GetUserPosition(UserId);
                if (position != null)
                {
                    if (position.isSuperUser.Equals("Y"))
                        hfIsSuperUser.Value = "Y";
                    else
                        hfIsSuperUser.Value = "N";

                    hfUserPosition.Value = position.Position;
                }

                if (!string.IsNullOrWhiteSpace(ID))
                {
                    var designerCtl = new TeamMemberController();
                    var designer = designerCtl.GetDesigner(Convert.ToInt32(ID)).First();
                    if (designer.Status == 0 || designer.Status == 2) //Pending Create, Pending Delete
                    {
                        if (hfIsSuperUser.Value.Equals("Y"))
                        {
                            pnlDesignerDetails.Enabled = false;
                            btnApprove.Enabled = true;
                            btnReject.Enabled = true;
                            btnCancel.Enabled = true;

                            btnApprove.Visible = true;
                            btnReject.Visible = true;
                            btnCreate.Visible = false;
                            btnDelete.Visible = false;
                            btnCancel.Visible = true;
                        }
                        else
                        {
                            pnlDesignerDetails.Enabled = false;
                            btnCreate.Enabled = false;
                            btnCancel.Enabled  = true;

                            btnApprove.Visible = false;
                            btnReject.Visible = false;                            
                            btnDelete.Visible = false;
                            btnCreate.Visible = true;
                            btnCancel.Visible = true;
                        }

                    }
                    else
                    {
                        btnApprove.Visible = false;
                        btnReject.Visible = false;
                        btnDelete.Visible = true;
                        btnCreate.Visible = true;
                    }

                    btnCreate.Text = Localization.GetString("btnSave", LocalResourceFile);

                    Page.ClientScript.RegisterStartupScript(this.GetType(), "addDesigner", "$(document).ready(function(){ $('#" + txtDesignerName.ClientID + "').tokenInput('add',{" +
                               "id:" + UserId + ",name:'" + UserController.GetUserById(PortalId, designer.StaffID).DisplayName
                               + "'}); $('.token-input-delete-token-facebook').remove(); }); ", true);

                    txtJobLevel.Text = Convert.ToString(designer.JobLevel);
                    txtHourlyRate.Text = Convert.ToString(designer.HourlyRate);
                    txtRemarks.Text = designer.Remark;
                }
                else
                {
                    btnCreate.Text = Localization.GetString("btnCreate", LocalResourceFile);
                    btnDelete.Visible = false;
                    btnApprove.Visible = false;
                    btnReject.Visible = false;
                }

                txtRemarks.Attributes.Add("placeholder", Localization.GetString("lblRemarksPlaceHolder", LocalResourceFile));
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect(EditUrl("DesignerView"));
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {

            var ID = Request.QueryString["ID"];

            var designerCtl = new TeamMemberController();

            Components.TeamMember designer;

            if(!string.IsNullOrWhiteSpace(ID))
            {                
                designer = designerCtl.GetDesigner(Convert.ToInt32(ID)).First();
                designer.JobLevel = Convert.ToInt32(txtJobLevel.Text);
                designer.HourlyRate = Convert.ToDouble(txtHourlyRate.Text);
                designer.Remark = txtRemarks.Text;
                designer.LastUpdateDate = DateTime.Now;
                designer.LastUpdatedBy = UserId;
                designerCtl.UpdateDesigner(designer);
            }
            else
            {
                if (designerCtl.IsTeamMemberExist(1,Convert.ToInt32(txtDesignerName.Text)).Count()>0)
                {
                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "DesignerExist", "alert('" + Localization.GetString("errmsg_DesignerExist.Text", LocalResourceFile) + "');", true);
                    return;
                }

                designer = new Components.TeamMember();
                designer.TeamID = 1;
                designer.StaffID = Convert.ToInt32(txtDesignerName.Text);
                designer.isManager = "N";
                designer.isTeamLeader = "N";
                designer.isDesigner = "Y";
                designer.isProjectSales = "N";
                designer.JobLevel = Convert.ToInt32(txtJobLevel.Text);
                designer.HourlyRate = Convert.ToDouble(txtHourlyRate.Text);
                designer.Remark = txtRemarks.Text;                
                designer.Status = hfIsSuperUser.Value.Equals("Y") ? 1 : 0;
                designer.CreateDate = DateTime.Now;
                designer.CreatedBy = UserId;                
                designer.LastUpdateDate = DateTime.Now;
                designer.LastUpdatedBy = UserId;

                designerCtl.CreateTeamMember(designer);

                if (!hfIsSuperUser.Value.Equals("Y"))
                    sendApprovalMail(designer);
            }
            Response.Redirect(EditUrl("DesignerView"));
        }

        protected void btnApprove_Click(object sender, EventArgs e)
        {
            var ID = Request.QueryString["ID"];
            var designerCtl = new TeamMemberController();
            var designer = designerCtl.GetDesigner(Convert.ToInt32(ID)).First();
            designer.Status = 2;
            designerCtl.UpdateDesigner(designer);
            Response.Redirect(EditUrl("DesignerView"));
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            var ID = Request.QueryString["ID"];
            var designerCtl = new TeamMemberController();
            var designer = designerCtl.GetDesigner(Convert.ToInt32(ID)).First();
            designer.Status = -1;
            designerCtl.UpdateDesigner(designer);
            Response.Redirect(EditUrl("DesignerView"));
        }
    

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            var ID = Request.QueryString["ID"];
            var designerCtl = new TeamMemberController();
            Components.TeamMember designer;            
            designer = designerCtl.GetDesigner(Convert.ToInt32(ID)).First();
            designer.ID = Convert.ToInt32(ID);
            designer.JobLevel = Convert.ToInt32(txtJobLevel.Text);
            designer.HourlyRate = Convert.ToDouble(txtHourlyRate.Text.ToString());
            designer.Remark = txtRemarks.Text;
            designer.Status = hfIsSuperUser.Value.Equals("Y") ? 3 : 2;
            designerCtl.UpdateDesigner(designer);
            if (!hfIsSuperUser.Value.Equals("Y"))
                sendApprovalMail(designer);

            Response.Redirect(EditUrl("DesignerView"));
        }

        protected void sendApprovalMail(Components.TeamMember dr)
        {
            ViewUserPositionControl ViewUserPositionCtl = new ViewUserPositionControl();
            var superUsers = ViewUserPositionCtl.GetSuperUsers();
            StringBuilder mailTo = new StringBuilder();

            foreach (ViewUserPosition v in superUsers)
            {
                if (!string.IsNullOrWhiteSpace(mailTo.ToString()))
                    mailTo.Append(";");
                mailTo.Append(v.email);
            }

            string mailAction= dr.Status == 0 ? Localization.GetString("mailSubject_Creation", LocalResourceFile) : dr.Status == 2 ? Localization.GetString("mailSubject_Deletion", LocalResourceFile) : string.Empty;
            string mailSubject = string.Format(Localization.GetString("mailSubject", LocalResourceFile), mailAction);
            string mailCSS = "<style type='text/css'>a.AcceptAction{color:darkgreen;padding:6px;}a.RejectAction{color:red;padding:6px;}</style>";
            string approvalRequestLink = "http://" + Request.Url.Host + "/DesktopModules/StudioOperationSystem/API/WebApiSOS/DeisgnerApprovalByMail?ID=" + Convert.ToString(dr.ID) + "&Action=";
            string webLink = EditUrl(string.Empty, string.Empty, "DesignerDetails", "ID", Convert.ToString(dr.ID));

            StringBuilder mailBody = new StringBuilder();
            mailBody.Append(mailCSS);
            mailBody.Append(string.Format(Localization.GetString("mailBody",LocalResourceFile), new string[] {
                mailAction,
                UserController.GetUserById(PortalId, dr.StaffID).DisplayName,
                Convert.ToString(dr.JobLevel) ,
                Convert.ToString(dr.HourlyRate),
                approvalRequestLink + "A",
                approvalRequestLink + "R",
                webLink
            }));
            SendMail(mailTo.ToString(), string.Empty, string.Empty, mailSubject, mailBody.ToString());
        }
    }
}