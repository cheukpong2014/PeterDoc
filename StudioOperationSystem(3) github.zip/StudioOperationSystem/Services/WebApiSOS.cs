﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DotNetNuke.Web.Api;
using System.Web.Http;
using System.Net.Http;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Users;
using System.Net;
using Milton.Modules.StudioOperationSystem.Components;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using DotNetNuke.Services.Localization;
using System.Drawing;

namespace Milton.Modules.StudioOperationSystem.Services
{
    public class WebApiSOSController : DnnApiController
    {
        private class SearchResult
        {
            // ReSharper disable InconsistentNaming
            // ReSharper disable NotAccessedField.Local
            public int id;
            public string name;
            public string email;
            public string dept;
            // ReSharper restore NotAccessedField.Local
            // ReSharper restore InconsistentNaming
        }

        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage SearchUser(string q)
        {
            try
            {
                var portalId = PortalController.GetEffectivePortalId(PortalSettings.PortalId);
                const int numResults = 5;

                // GetUsersAdvancedSearch doesn't accept a comma or a single quote in the query so we have to remove them for now. See issue 20224.
                q = q.Replace(",", "").Replace("'", "");
                if (q.Length == 0) return Request.CreateResponse<SearchResult>(HttpStatusCode.OK, null);

                var results = UserController.Instance.GetUsersBasicSearch(portalId, 0, numResults, "DisplayName", true, "DisplayName", q)
                    .Select(user => new SearchResult
                    {
                        id = user.UserID,
                        name = user.DisplayName,
                        email = user.Email,
                        dept = user.Profile.GetPropertyValue("Department")
                    }).ToList();

                return Request.CreateResponse(HttpStatusCode.OK, results.OrderBy(sr => sr.name));
            }
            catch (Exception exc)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, exc);
            }
        }

        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage getServerTime()
        {
            HttpResponseMessage response = new HttpResponseMessage();
            response.Content = new StringContent(DateTime.Now.ToString(), Encoding.UTF8, "text/html");
            response.StatusCode = HttpStatusCode.OK;
            return response;
        }
        
        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage getProjectTimeByDesigner(string projectID)
        {
            DesignerTimerController _DesignerTimerCtl = new DesignerTimerController();
            IEnumerable<DesignerTimer> _DesignerTimer = _DesignerTimerCtl.GetDesignerTimer(UserInfo.UserID, Convert.ToInt32(projectID)).OrderByDescending( _result => _result.ActionTime);
            string result_time = string.Empty;

            if (_DesignerTimer.Count() > 0)
            {
                TimeSpan totalTime = DateTime.Now - DateTime.Now;
                DateTime lastPauseTime = DateTime.Now;

                foreach (DesignerTimer _d in _DesignerTimer)
                {
                    if (_d.ActionType.Equals("S"))
                    {
                        totalTime += lastPauseTime - _d.ActionTime;
                    }
                    else if (_d.ActionType.Equals("P"))
                    {
                        lastPauseTime = _d.ActionTime;
                    }
                }

                DesignerTimer _d_first = _DesignerTimer.FirstOrDefault();
                return Request.CreateResponse(HttpStatusCode.OK, new { type = _d_first.ActionType, time = totalTime.TotalMilliseconds.ToString() }, Configuration.Formatters.JsonFormatter);
            }
            else
                return Request.CreateResponse(HttpStatusCode.OK, new { type = "P", time = "0" }, Configuration.Formatters.JsonFormatter);
        }

        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage setProjectStartTime(string projectID)
        {
            DesignerTimerController _DesignerTimerCtl = new DesignerTimerController();
            DesignerTimer _DesignerTimer = new DesignerTimer();
            _DesignerTimer.ActionType = "S";
            _DesignerTimer.ActionTime = DateTime.Now;
            _DesignerTimer.DesignerID = UserInfo.UserID;
            _DesignerTimer.ProjectID = Convert.ToInt32(projectID);
            _DesignerTimerCtl.CreateDesignerTimer(_DesignerTimer);
            
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage setProjectPauseTime(string projectID)
        {
            DesignerTimerController _DesignerTimerCtl = new DesignerTimerController();
            DesignerTimer _DesignerTimer = _DesignerTimerCtl.GetDesignerStartedTimer(UserInfo.UserID, Convert.ToInt32(projectID)).OrderByDescending(_result => _result.ActionTime).FirstOrDefault();
            _DesignerTimer.ActionType = "P";
            _DesignerTimer.ActionTime = DateTime.Now;
            _DesignerTimer.DesignerID = UserInfo.UserID;
            _DesignerTimer.ProjectID = Convert.ToInt32(projectID);
            _DesignerTimerCtl.CreateDesignerTimer(_DesignerTimer);

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage getEvents(string pid)
        {
            try
            {

                var portalId = PortalController.GetEffectivePortalId(PortalSettings.PortalId);
                var bookingDataCtl = new BookingDataController();
                var projectTypeCtl = new ProjectTypeControl();
                var projectCtl = new ProjectControl();

                var evts = bookingDataCtl.GetBookingByProjectId(Convert.ToInt32(pid));
                if (evts.Count() > 0)
                {

                    var result = evts.Select(e => new { id = e.id.ToString(), title = projectCtl.GetProject(e.ProjectID).Code + " - " + UserController.GetUserById(portalId, e.DesignerID).DisplayName, start = e.start, end = e.end, color = projectCtl.GetProject(e.ProjectID).Color, resourceId = e.DesignerID, borderColor = "black" });
                    return Request.CreateResponse(HttpStatusCode.OK, result.ToList(), Configuration.Formatters.JsonFormatter);
                }
                else
                    return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception exc)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, exc);
            }
        }

        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage getAllEvents(string UserId)
        {
            try
            {
                var portalId = PortalController.GetEffectivePortalId(PortalSettings.PortalId);
                var bookingDataCtl = new BookingDataController();
                var projectTypeCtl = new ProjectTypeControl();
                var projectCtl = new ProjectControl();
                int Uid = Convert.ToInt32(UserId);
                var positionCtl = new UserPositionControl();
                var position = positionCtl.GetUserPosition(Uid);

                var evts = bookingDataCtl.GetBookings();
                if (evts.Count() > 0)
                {
                    //return a new result customs format.
                    var result = evts.Select(e => new { id = e.id.ToString(), title = projectCtl.GetProject(e.ProjectID).Code + " - " + UserController.GetUserById(portalId, e.DesignerID).DisplayName, start = e.start, end = e.end, color = projectCtl.GetProject(e.ProjectID).Color, resourceId = e.DesignerID, borderColor = "black", textColor = "rgb(" + Color.FromArgb(ColorTranslator.FromHtml(projectCtl.GetProject(e.ProjectID).Color).ToArgb() ^ 0xffffff).R + ", " + Color.FromArgb(ColorTranslator.FromHtml(projectCtl.GetProject(e.ProjectID).Color).ToArgb() ^ 0xffffff).G + ", " + Color.FromArgb(ColorTranslator.FromHtml(projectCtl.GetProject(e.ProjectID).Color).ToArgb() ^ 0xffffff).B + ")" });

                    if (position != null)
                        if (!string.IsNullOrWhiteSpace(position.Position))
                            if (!position.isSuperUser.ToUpper().Equals("Y") && position.Position.ToUpper().Equals("PS"))
                                result = evts.Select(e => new { id = e.id.ToString(), title = projectCtl.GetProject(e.ProjectID).ProjectSales.Equals(Uid) ? projectCtl.GetProject(e.ProjectID).ShowName + " - " + UserController.GetUserById(portalId, e.DesignerID).DisplayName : "***assigned***" + " - " + UserController.GetUserById(portalId, e.DesignerID).DisplayName, start = e.start, end = e.end, color = projectCtl.GetProject(e.ProjectID).Color, resourceId = e.DesignerID, borderColor = "black", textColor = "rgb(" + Color.FromArgb(ColorTranslator.FromHtml(projectCtl.GetProject(e.ProjectID).Color).ToArgb() ^ 0xffffff).R + ", " + Color.FromArgb(ColorTranslator.FromHtml(projectCtl.GetProject(e.ProjectID).Color).ToArgb() ^ 0xffffff).G + ", " + Color.FromArgb(ColorTranslator.FromHtml(projectCtl.GetProject(e.ProjectID).Color).ToArgb() ^ 0xffffff).B + ")" });

                    return Request.CreateResponse(HttpStatusCode.OK, result.ToList(), Configuration.Formatters.JsonFormatter);
                }
                else
                    return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception exc)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, exc);
            }
        }


        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage getAllEventsByDesigner(string UserId)
        {
            try
            {
                var portalId = PortalController.GetEffectivePortalId(PortalSettings.PortalId);
                var bookingDataCtl = new BookingDataController();
                var projectTypeCtl = new ProjectTypeControl();
                var projectCtl = new ProjectControl();
                int Uid = Convert.ToInt32(UserId);
                var positionCtl = new UserPositionControl();

                var evts = bookingDataCtl.GetBookingByDesignerId(Uid);
                if (evts.Count() > 0)
                {
                    //return a new result customs format.
                    var result = evts.Select(e => new { id = e.id.ToString(), title = projectCtl.GetProject(e.ProjectID).Code + " - " + UserController.GetUserById(portalId, e.DesignerID).DisplayName, start = e.start, end = e.end, color = projectCtl.GetProject(e.ProjectID).Color, resourceId = e.DesignerID, borderColor = "black", textColor = "rgb(" + Color.FromArgb(ColorTranslator.FromHtml(projectCtl.GetProject(e.ProjectID).Color).ToArgb() ^ 0xffffff).R + ", " + Color.FromArgb(ColorTranslator.FromHtml(projectCtl.GetProject(e.ProjectID).Color).ToArgb() ^ 0xffffff).G + ", " + Color.FromArgb(ColorTranslator.FromHtml(projectCtl.GetProject(e.ProjectID).Color).ToArgb() ^ 0xffffff).B + ")" });
                    return Request.CreateResponse(HttpStatusCode.OK, result.ToList(), Configuration.Formatters.JsonFormatter);
                }
                else
                    return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception exc)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, exc);
            }
        }

        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage getAllDesigners()
        {
            try
            {
                var portalId = PortalController.GetEffectivePortalId(PortalSettings.PortalId);
                var designerCtl = new TeamMemberController();
                var projectCtl = new ProjectControl();
                var dgrs = designerCtl.GetActiveDesigners();
                if (dgrs.Count() > 0)
                {
                    //return a new result customs format.
                    var result = dgrs.Select(d => new { id = d.StaffID, title = UserController.GetUserById(portalId, d.StaffID).DisplayName });

                    return Request.CreateResponse(HttpStatusCode.OK, result.ToList(), Configuration.Formatters.JsonFormatter);
                }
                else
                    return Request.CreateResponse(HttpStatusCode.OK, string.Empty);
            }
            catch (Exception exc)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, exc);
            }
        }

        //[DnnAuthorize]
        //[HttpGet]
        //public HttpResponseMessage getActiveDesigners(string q)
        //{
        //    try
        //    {
        //        var portalId = PortalController.GetEffectivePortalId(PortalSettings.PortalId);
        //        var designerCtl = new ViewDesignerControl();
        //        var dgrs = designerCtl.GetDesignerView(q);
        //        if (dgrs.Count() > 0)
        //        {
        //            //return a new result customs format.
        //            var result = dgrs.Select(d => new { id = d.UserId, name = d.UserName, email=d.email });

        //            return Request.CreateResponse(HttpStatusCode.OK, result.ToList(), Configuration.Formatters.JsonFormatter);
        //        }
        //        else
        //            return Request.CreateResponse(HttpStatusCode.OK);
        //    }
        //    catch (Exception exc)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, exc);
        //    }
        //}

        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage DeisgnerApprovalByMail(string ID, string Action)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            var designerCtl = new TeamMemberController();
            var designerCtl_result = designerCtl.GetPendingDesigner(Convert.ToInt32(ID));
            if (designerCtl_result.Count() == 1)
            {
                var designer = designerCtl_result.FirstOrDefault();
                designer.Status = Action.Equals("A") ? designer.Status + 1 : designer.Status - 1;
                designerCtl.UpdateDesigner(designer);
                response.Content = new StringContent("<p style='border:1px solid powderblue;padding: 30px; '>The request is " + (Action.Equals("A") ? "approved" : "rejected") + " succssfully.<p>", Encoding.UTF8, "text/html");
            }
            else               
                response.Content = new StringContent("<p style='border:1px solid powderblue;padding: 30px; '>The record have not been existed (it may be occurred by already approved/rejected by someone), or the record is invalid. Please contact helpdesk support.<p>", Encoding.UTF8, "text/html"); 
            response.StatusCode = HttpStatusCode.OK;
            return response;
        }

        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage ProjectApprovalByMail(string ID, string Action)
        {
            HttpResponseMessage response = new HttpResponseMessage();

            ProjectControl ProjectCtl = new ProjectControl();
            PreProjectControl PendingProjectCtl = new PreProjectControl();
            
            PendingProject PendingProject = PendingProjectCtl.GetProject(Convert.ToInt32(ID));
            Project Project = ProjectCtl.GetProject(Convert.ToInt32(ID));

            if (PendingProject != null && Project != null)
            {
                if (Action.Equals("A"))
                {
                    Project.ID = PendingProject.ID;
                    Project.Code = PendingProject.Code;
                    //Project.Name = PendingProject.Name;
                    Project.Client = PendingProject.Client;
                    Project.ShowName = PendingProject.ShowName;
                    Project.ShowDateFrom = PendingProject.ShowDateFrom;
                    Project.ShowDateTo = PendingProject.ShowDateTo;
                    Project.Deadline = PendingProject.Deadline;
                    Project.Venue = PendingProject.Venue;
                    Project.Location = PendingProject.Location;
                    Project.Amount = PendingProject.Amount;
                    Project.Scope = PendingProject.Scope;
                    Project.Size = PendingProject.Size;
                    Project.Status = PendingProject.Status;
                    Project.Remark = PendingProject.Remark;
                    Project.Type = PendingProject.Type;
                    Project.ProjectSales = PendingProject.ProjectSales;
                    Project.StudioTeamLead = PendingProject.StudioTeamLead;
                    Project.Color = PendingProject.Color;

                    ProjectCtl.UpdateProject(Project);
                    PendingProjectCtl.DeleteProject(PendingProject);

                    response.Content = new StringContent("<p style='border:1px solid powderblue;padding: 30px; '>The request is approved succssfully.<p>", Encoding.UTF8, "text/html");
                }
                else if (Action.Equals("R"))
                {
                    PendingProjectCtl.DeleteProject(Convert.ToInt32(ID));
                    response.Content = new StringContent("<p style='border:1px solid powderblue;padding: 30px; '>The request is rejected succssfully.<p>", Encoding.UTF8, "text/html");
                }

            }
            else
                response.Content = new StringContent("<p style='border:1px solid powderblue;padding: 30px; '>The record have not been existed (it may be occurred by already approved/rejected by someone), or the record is invalid. Please contact helpdesk support.<p>", Encoding.UTF8, "text/html");
            response.StatusCode = HttpStatusCode.OK;
            return response;


            //if (project != null)
            //{
            //    response.StatusCode = HttpStatusCode.OK;

            //    var _updatePjt = updatePjtCtl.GetProject(Convert.ToInt32(ID));
            //    if (Action == "A")
            //    {

            //        project.Client = _updatePjt.Client;
            //        project.Amount = _updatePjt.Amount;
            //        project.Location = _updatePjt.Location;
            //        project.Name = _updatePjt.Name;
            //        project.ShowName = _updatePjt.ShowName;
            //        project.Scope = _updatePjt.Scope;
            //        project.Remark = _updatePjt.Remark;
            //        project.Size = _updatePjt.Size;
            //        project.Venue = _updatePjt.Venue;
            //        project.Deadline = _updatePjt.Deadline;
            //        project.ShowDate = _updatePjt.ShowDate;
            //        project.Type = _updatePjt.Type;
            //        project.Color = _updatePjt.Color;
            //        project.Status = _updatePjt.Status;
            //        projectCtl.UpdateProject(project);
            //        updatePjtCtl.DeleteProject(_updatePjt);

            //        if (project.Status == 6)
            //        {
            //            var bkCtl = new BookingDataController();

            //            foreach (var b in bkCtl.GetBookingByProjectIdandDate(project.ID, new DateTime()))
            //            {
            //                bkCtl.DeleteBooking(b);
            //            }
            //        }
            //        response.Content = new StringContent("<p style='border:1px solid powderblue;padding: 30px; '>Approved the Designer.<p>", Encoding.UTF8, "text/html");

            //    }
            //    else if (Action == "R")
            //    {
            //        updatePjtCtl.DeleteProject(_updatePjt);
            //        response.Content = new StringContent("Reject the Project's Change.");
            //    }
            //    return response;
            //    //return Request.CreateResponse(HttpStatusCode.OK);
            //}
            //else
            //    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Project haven't Create before.");
        }

        //[DnnAuthorize]
        //[HttpGet]
        //public HttpResponseMessage getEventsByDesigner(string DesignerID, string start, string end)
        //{
        //    try
        //    {

        //        var portalId = PortalController.GetEffectivePortalId(PortalSettings.PortalId);
        //        var bookingDataCtl = new BookingDataController();
        //        var projectTypeCtl = new ProjectTypeControl();
        //        var projectCtl = new ProjectControl();
        //        var evts = bookingDataCtl.GetBookingByDesignerId(Convert.ToInt32(DesignerID));
        //        if (evts.Count() > 0)
        //        {
        //            var result = evts.Select(e => new { id = e.id.ToString(), title = projectCtl.GetProject(e.ProjectID).ShowName + " - " + UserController.GetUserById(portalId, e.DesignerID).DisplayName, start = e.start, end = e.end, color = projectCtl.GetProject(e.ProjectID).Color, borderColor = "black" });
        //            //var jsonSerialiser = new JavaScriptSerializer();
        //            //return Request.CreateResponse(HttpStatusCode.OK, jsonSerialiser.Serialize(result));
        //            return Request.CreateResponse(HttpStatusCode.OK, result.ToList(), Configuration.Formatters.JsonFormatter);
        //        }
        //        else
        //            return Request.CreateResponse(HttpStatusCode.OK);
        //    }
        //    catch (Exception exc)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, exc);
        //    }
        //}

        [DnnAuthorize]
        [HttpGet]
        public HttpResponseMessage GetAllTeamLead(string q)
        {
            try
            {
                var portalId = PortalController.GetEffectivePortalId(PortalSettings.PortalId);
                var viewCtl = new ViewUserPositionControl();
                var ups = viewCtl.SearchTeamLeads(q);
                if (ups.Count() > 0)
                {
                    var result = ups.Select(up => new { id = up.UserId, name = up.UserName, email = up.email });
                    return Request.CreateResponse(HttpStatusCode.OK, result.ToList(), Configuration.Formatters.JsonFormatter);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.OK);
                }
            }
            catch (Exception exc)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, exc);
            }

        }

        public string DecryptText(string input, string password)
        {
            // Get the bytes of the string
            byte[] bytesToBeDecrypted = Convert.FromBase64String(input);
            byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
            passwordBytes = SHA256.Create().ComputeHash(passwordBytes);

            byte[] bytesDecrypted = AES_Decrypt(bytesToBeDecrypted, passwordBytes);

            string result = Encoding.UTF8.GetString(bytesDecrypted);

            return result;
        }

        public byte[] AES_Decrypt(byte[] bytesToBeDecrypted, byte[] passwordBytes)
        {
            byte[] decryptedBytes = null;

            // Set your salt here, change it to meet your flavor:
            // The salt bytes must be at least 8 bytes.
            byte[] saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

            using (MemoryStream ms = new MemoryStream())
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;

                    var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
                    AES.Key = key.GetBytes(AES.KeySize / 8);
                    AES.IV = key.GetBytes(AES.BlockSize / 8);

                    AES.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(ms, AES.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
                        cs.Close();
                    }
                    decryptedBytes = ms.ToArray();
                }
            }

            return decryptedBytes;
        }


    }
}