﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Milton.Modules.StudioOperationSystem.Components;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Services.Localization;
using DotNetNuke.Security;
using DotNetNuke.Entities.Modules;

namespace Milton.Modules.StudioOperationSystem
{
    public partial class ManagerPage : StudioOperationSystemModuleBase, IActionable
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    var projectCtl = new ProjectControl();
                    var project = projectCtl.GetProjectsByProjectSales(UserId);
                    if (project.Count() > 0)
                    {
                        rptProject.DataSource = from pt in project select new
                        {
                            showName = pt.ShowName,
                            id = pt.ID
                        };
                        rptProject.DataBind();
                    }
                }
            }catch (Exception exc)
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        public ModuleActionCollection ModuleActions
        {
            get
            {
                var actions = new ModuleActionCollection
                    {
                        {
                            GetNextActionID(), Localization.GetString("EditModule", LocalResourceFile), "", "", "",
                            EditUrl(), false, SecurityAccessLevel.Edit, true, false
                        }
                    };
                return actions;
            }
        }

        protected void btnGoToProject(object sender, EventArgs e)
        {

            Response.Redirect(EditUrl("ProjectView"));
        }

    }
}