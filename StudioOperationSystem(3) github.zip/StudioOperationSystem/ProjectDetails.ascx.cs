﻿using DotNetNuke.Entities.Users;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Services.Localization;
using Milton.Modules.StudioOperationSystem.Components;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Milton.Modules.StudioOperationSystem
{
    public partial class ProjectDetails : StudioOperationSystemModuleBase
    {
        #region "Page Events"
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ddlProjectType_DataBind(ddlProjectType);
                ddlStatus_DataBind();
                ProjectTypePending.Visible = false;
                //ProjectNamePending.Visible = false;
                StatusPending.Visible = false;
                DeadlinePending.Visible = false;
                ClientPending.Visible = false;
                ShowNamePending.Visible = false;
                ShowDateFromPending.Visible = false;
                ShowDateToPending.Visible = false;
                ColorPending.Visible = false;
                VenuePending.Visible = false;
                SizePending.Visible = false;
                LocationPending.Visible = false;
                TeamLeadPending.Visible = false;
                BudgetPending.Visible = false;
                ProjectScopePending.Visible = false;
                RemarksPending.Visible = false;

                UserPositionControl UserPositionCtl = new UserPositionControl();
                UserPosition UserPosition = UserPositionCtl.GetUserPosition(UserId);
                var permission = false;
                if (UserPosition != null)
                {
                    if (UserPosition.isSuperUser.Equals("Y"))
                        hfIsSuperUser.Value = "Y";
                    else
                        hfIsSuperUser.Value = "N";

                    hfUserPosition.Value = UserPosition.Position;
                    if (UserPosition.Position == "PS")
                        permission = true;
                }
                int ID = string.IsNullOrWhiteSpace(Request.QueryString["ID"]) ? 0 : Convert.ToInt32(Request.QueryString["ID"]);
                if (ID > 0)
                {
                    #region Edit Mode
                    //forbidden other user to change this page
                    var project = loadProjDetails(ID);
                    string temp = string.Empty;
                    if (!permission || project.Status == 1 || project.Status == 5 || (!hfIsSuperUser.Value.Equals("Y") && hfUserPosition.Value.Equals("TL")))
                    {
                        temp = "$('.token-input-delete-token-facebook').remove();";
                        rColor.CssClass = string.Empty;
                        rColor.Attributes.Add("style", "background-color: " + rColor.Text);
                        pnlProjectDetails.Enabled = false;
                        btnSave.Visible = false;
                        btnCancel.Text = Localization.GetString("btnBack", LocalResourceFile);
                    }
                    if (project.StudioTeamLead != null)
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "addTeamLead", "$(document).ready(function(){ $('#" + txtTeamLead.ClientID + "').tokenInput('add',{" +
                        "id:'" + Convert.ToString(project.StudioTeamLead) + "' ,name:'" + UserController.GetUserById(PortalId, Convert.ToInt32(project.StudioTeamLead)).DisplayName +  "'}); " + temp + " });", true);
                    #endregion
                }
                else
                {
                    ltlProjectCode.Text = Localization.GetString("ltlProjectCode", LocalResourceFile);
                    ddlStatus.Enabled = false;
                }

            }
        }
        #endregion

        protected Project loadProjDetails(int ID)
        {
            ProjectControl ProjectCtl = new ProjectControl();
            PreProjectControl PendingProjectCtl = new PreProjectControl();
            //project
            var project = ProjectCtl.GetProject(ID);
            ltlProjectCode.Text = project.Code;
            ddlProjectType.SelectedValue = project.Type.ToString();
            //txtProjectName.Text = project.Name;
            ddlStatus.SelectedValue = project.Status.ToString();
            txtDeadline.Text = project.Deadline.ToString("yyyy-MM-dd");
            hfDeadLineDate.Value = project.Deadline.ToString("yyyy-MM-dd");
            txtClient.Text = project.Client;
            txtShowName.Text = project.ShowName;
            txtShowDateFrom.Text = project.ShowDateFrom.ToString("yyyy-MM-dd");
            txtShowDateTo.Text = project.ShowDateTo.ToString("yyyy-MM-dd");
            hfShowDateFrom.Value = project.ShowDateFrom.ToString("yyyy-MM-dd");
            hfShowDateTo.Value = project.ShowDateTo.ToString("yyyy-MM-dd");
            rColor.Text = project.Color;
            txtVenue.Text = project.Venue;
            txtSize.Text = project.Size;
            txtLocation.Text = project.Location;
            hfSelectedTeamLead.Value = project.StudioTeamLead == null ? string.Empty : Convert.ToString(project.StudioTeamLead);
            txtBudget.Text = project.Amount.ToString();
            txtProjectScope.Text = project.Scope;
            txtRemark.Text = project.Remark;
            //padding
            var project_pending = PendingProjectCtl.GetProject(ID);
            if (project_pending != null)
            {
                ddlStatusPending_DataBind(ddlStatus);
                ddlStatusPending_DataBind(ddlStatusPending);

                ltlProjectCode.Text = project_pending.Code;

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.Type.Equals(project.Type)))
                    ddlProjectType.SelectedValue = project_pending.Type.ToString();
                else
                {
                    ddlProjectType_DataBind(ddlProjectTypePending);
                    ProjectTypePending.Visible = true;
                    ddlProjectType.SelectedValue = project.Type.ToString();
                    ddlProjectTypePending.SelectedValue = project_pending.Type.ToString();
                }

                //if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.Name.Equals(project.Name)))
                //    txtProjectName.Text = project_pending.Name;
                //else
                //{
                //    ProjectNamePending.Visible = true;
                //    txtProjectName.Text = project.Name;
                //    txtProjectNamePending.Text = project_pending.Name;
                //}

                if (!hfIsSuperUser.Value.Equals("Y"))
                {
                    ddlStatus.SelectedValue = Convert.ToString(project_pending.Status - 1);
                }
                else
                {
                    StatusPending.Visible = true;
                    ddlStatus.SelectedValue = Convert.ToString(project.Status);
                    ddlStatusPending.SelectedValue = Convert.ToString(project_pending.Status);
                }


                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.Deadline.Equals(project.Deadline)))
                    txtDeadline.Text = project_pending.Deadline.ToString("yyyy-MM-dd");
                else
                {
                    DeadlinePending.Visible = true;
                    txtDeadline.Text = project.Deadline.ToString("yyyy-MM-dd");
                    txtDeadlinePending.Text = project_pending.Deadline.ToString("yyyy-MM-dd");
                }
                hfDeadLineDate.Value = project_pending.Deadline.ToString("yyyy-MM-dd");

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.Client.Equals(project.Client)))
                    txtClient.Text = project_pending.Client;
                else
                {
                    ClientPending.Visible = true;
                    txtClient.Text = project.Client;
                    txtClientPending.Text = project_pending.Client;
                }

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.ShowName.Equals(project.ShowName)))
                    txtShowName.Text = project_pending.ShowName;
                else
                {
                    ShowNamePending.Visible = true;
                    txtShowName.Text = project.ShowName;
                    txtShowNamePending.Text = project_pending.ShowName;
                }

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.ShowDateFrom.Equals(project.ShowDateFrom)))
                    txtShowDateFrom.Text = project_pending.ShowDateFrom.ToString("yyyy-MM-dd");
                else
                {
                    ShowDateFromPending.Visible = true;
                    txtShowDateFrom.Text = project.ShowDateFrom.ToString("yyyy-MM-dd");
                    txtShowDateFromPending.Text = project_pending.ShowDateFrom.ToString("yyyy-MM-dd");
                }
                hfShowDateFrom.Value = project_pending.ShowDateFrom.ToString("yyyy-MM-dd");


                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.ShowDateTo.Equals(project.ShowDateTo)))
                    txtShowDateTo.Text = project_pending.ShowDateTo.ToString("yyyy-MM-dd");
                else
                {
                    ShowDateToPending.Visible = true;
                    txtShowDateTo.Text = project.ShowDateTo.ToString("yyyy-MM-dd");
                    txtShowDateToPending.Text = project_pending.ShowDateTo.ToString("yyyy-MM-dd");
                }
                hfShowDateTo.Value = project_pending.ShowDateTo.ToString("yyyy-MM-dd");

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.Color.Equals(project.Color)))
                {
                    rColor.Text = project_pending.Color;
                    rColor.BackColor = ColorTranslator.FromHtml(project_pending.Color);

                }
                else
                {
                    ColorPending.Visible = true;
                    rColor.Text = project.Color;
                    rColor.BackColor = ColorTranslator.FromHtml(project.Color);
                    rColor.ForeColor = Color.FromArgb(rColor.BackColor.ToArgb() ^ 0xffffff);

                    txtColorPending.Text = project_pending.Color;
                    txtColorPending.BackColor = ColorTranslator.FromHtml(project_pending.Color);
                    txtColorPending.ForeColor = Color.FromArgb(rColor.BackColor.ToArgb() ^ 0xffffff);

                }
                rColor.CssClass = string.Empty;
                rColor.ForeColor = Color.FromArgb(rColor.BackColor.ToArgb() ^ 0xffffff);

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.Venue.Equals(project.Venue)))
                    txtVenue.Text = project_pending.Venue;
                else
                {
                    VenuePending.Visible = true;
                    txtVenue.Text = project.Venue;
                    txtVenuePending.Text = project_pending.Venue;

                }

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.Size.Equals(project.Size)))
                    txtSize.Text = project_pending.Size;
                else
                {
                    SizePending.Visible = true;
                    txtSize.Text = project.Size;
                    txtSizePending.Text = project_pending.Size;
                }

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.Location.Equals(project.Location)))
                    txtLocation.Text = project_pending.Location;
                else
                {
                    LocationPending.Visible = true;
                    txtLocation.Text = project.Location;
                    txtLocationPending.Text = project_pending.Location;
                }

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.StudioTeamLead.Equals(project.StudioTeamLead)))
                {
                    if (project_pending.StudioTeamLead != null)
                        Page.ClientScript.RegisterStartupScript(GetType(),
                            "addTeamLead", "$(document).ready(function(){ $('#" + txtTeamLead.ClientID + "').tokenInput('add',{id:'" + Convert.ToString(project_pending.StudioTeamLead) + "' ,name:'" + UserController.GetUserById(PortalId, Convert.ToInt32(project_pending.StudioTeamLead)).DisplayName + "'}); $('.token-input-delete-token-facebook').remove(); });", true);
                    else
                        Page.ClientScript.RegisterStartupScript(GetType(),
                       "addTeamLead", "$(document).ready(function(){ $('#" + txtTeamLead.ClientID + "').tokenInput('tokenLimit', 0});", true);

                }
                else
                {
                    TeamLeadPending.Visible = true;
                    string temp_teamLead = string.Empty;
                    string temp_teamLeadPending = string.Empty;
                    if (project.StudioTeamLead != null)
                        temp_teamLead = "$('#" + txtTeamLead.ClientID + "').tokenInput('add',{ id: '" + Convert.ToString(project.StudioTeamLead) + "' ,name: '" + UserController.GetUserById(PortalId, Convert.ToInt32(project.StudioTeamLead)).DisplayName + "'}); $('.token-input-delete-token-facebook').remove();";
                    else
                    {
                        txtTeamLead.Visible = false;
                        txtTeamLead_NoData.Visible = true;
                    }
                    if (project_pending.StudioTeamLead != null)
                        temp_teamLeadPending = "$('#" + txtTeamLeadPending.ClientID + "').tokenInput('add',{id:'" + Convert.ToString(project_pending.StudioTeamLead) + "' ,name:'" + UserController.GetUserById(PortalId, Convert.ToInt32(project_pending.StudioTeamLead)).DisplayName + "'}); $('.token-input-delete-token-facebook').remove();";
                    else
                    {
                        txtTeamLeadPending.Visible = false;
                        txtTeamLeadPending_NoData.Visible = true;
                    }

                    Page.ClientScript.RegisterStartupScript(GetType(),
                        "addTeamLead", "$(document).ready(function(){ " + temp_teamLead + temp_teamLeadPending + " });", true);

                }

                hfSelectedTeamLead.Value = project_pending.StudioTeamLead == null ? string.Empty : Convert.ToString(project_pending.StudioTeamLead);

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.Amount.Equals(project.Amount)))
                    txtBudget.Text = Convert.ToString(project_pending.Amount);
                else
                {
                    BudgetPending.Visible = true;
                    txtBudget.Text = Convert.ToString(project.Amount);
                    txtBudgetPending.Text = Convert.ToString(project_pending.Amount);
                }

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.Scope.Equals(project.Scope)))
                    txtProjectScope.Text = project_pending.Scope;
                else
                {
                    ProjectScopePending.Visible = true;
                    txtProjectScope.Text = project.Scope;
                    txtProjectScopePending.Text = project_pending.Scope;
                }

                if (!hfIsSuperUser.Value.Equals("Y") || (hfIsSuperUser.Value.Equals("Y") && project_pending.Remark.Equals(project.Remark)))
                    txtRemark.Text = project_pending.Remark;
                else
                {
                    RemarksPending.Visible = true;
                    txtRemark.Text = project.Remark;
                    txtRemarksPending.Text = project_pending.Remark;
                }

                if (hfIsSuperUser.Value.Equals("Y"))
                {
                    btnApprove.Visible = true;
                    btnReject.Visible = true;
                }

                pnlProjectDetails.Enabled = false;
                btnSave.Visible = false;
                btnCancel.Text = Localization.GetString("btnBack", LocalResourceFile);
            }
            return project;
        }

        #region "Controls Events"
        protected void ddlProjectType_DataBind(DropDownList ddl)
        {
            var ctlddlProjectTypes = new ProjectTypeControl();
            ddl.DataSource = ctlddlProjectTypes.GetProjectTypes();
            ddl.DataTextField = "TypeDesc";
            ddl.DataValueField = "ID";
            ddl.DataBind();
        }

        protected void ddlStatus_DataBind()
        {
            var ProjectStatusCtl = new ProjectStatusControl();

            foreach (var projectStatus in ProjectStatusCtl.GetDisplayStatus())
            {
                projectStatus.Name = Localization.GetString(projectStatus.Name, LocalResourceFile);

            }

            ddlStatus.DataSource = ProjectStatusCtl.GetDisplayStatus();
            ddlStatus.DataTextField = "Name";
            ddlStatus.DataValueField = "ID";
            ddlStatus.DataBind();
        }

        protected void ddlStatusPending_DataBind(DropDownList ddl)
        {
            var ProjectStatusCtl = new ProjectStatusControl();

            foreach (var projectStatus in ProjectStatusCtl.GetStatuss())
            {
                projectStatus.Name = Localization.GetString(projectStatus.Name, LocalResourceFile);

            }

            ddl.DataSource = ProjectStatusCtl.GetStatuss();
            ddl.DataTextField = "Name";
            ddl.DataValueField = "ID";
            ddl.DataBind();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(EditUrl("ProjectView"));
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            var ct = System.Threading.Thread.CurrentThread.CurrentCulture.Name;
            var cti = CultureInfo.CreateSpecificCulture(ct);
            var ctlddlStatus = new ProjectStatusControl();

            int ID = string.IsNullOrWhiteSpace(Request.QueryString["ID"]) ? 0 : Convert.ToInt32(Request.QueryString["ID"]);

            var ctlProject = new ProjectControl();

            var upCtl = new UserPositionControl();
            var position = upCtl.GetUserPosition(UserId);

            string projectData = string.Empty;
            string emailTo = string.Empty;
            string emailFrom = string.Empty;
            string emailSubject = string.Empty;
            string emailBody = string.Empty;

            if (ID > 0)
            {
                var project = ctlProject.GetProject(ID);

                project.Client = txtClient.Text;
                project.Amount = Convert.ToDouble(txtBudget.Text);
                project.Location = txtLocation.Text;
                //project.Name = txtProjectName.Text;
                project.ShowName = txtShowName.Text;
                project.Scope = txtProjectScope.Text;
                project.Remark = txtRemark.Text;
                project.Size = txtSize.Text;
                project.Venue = txtVenue.Text;
                if (string.IsNullOrWhiteSpace(hfSelectedTeamLead.Value))
                    project.StudioTeamLead = null;
                else
                    project.StudioTeamLead = Convert.ToInt32(hfSelectedTeamLead.Value);
                project.Deadline = DateTime.ParseExact(txtDeadline.Text.Trim(), "yyyy-MM-dd", cti);
                project.ShowDateFrom = DateTime.ParseExact(txtShowDateFrom.Text.Trim(), "yyyy-MM-dd", cti);
                project.ShowDateTo = DateTime.ParseExact(txtShowDateTo.Text.Trim(), "yyyy-MM-dd", cti);
                project.Type = Convert.ToInt32(ddlProjectType.SelectedItem.Value);
                project.Color = '#' + rColor.Text;

                bool isNeedApproval = false;

                if (!position.isSuperUser.Equals("Y"))
                {
                    if (ddlStatus.SelectedValue == Convert.ToString(3))
                    {
                        //From other status change to postpone
                        if (project.Status != 3)
                        {
                            isNeedApproval = true;
                        }
                        //From postpone status, change the showdate/deadline date
                        else
                        {
                            if (!(hfDeadLineDate.Value.Equals(project.Deadline.ToString("yyyy-MM-dd")) && hfShowDateFrom.Value.Equals(project.ShowDateFrom.ToString("yyyy-MM-dd")) && hfShowDateTo.Value.Equals(project.ShowDateTo.ToString("yyyy-MM-dd"))))
                            {
                                isNeedApproval = true;
                            }
                        }
                    }
                    else if (ddlStatus.SelectedValue == Convert.ToString(5))
                    {
                        isNeedApproval = true;
                    }
                }

                if (isNeedApproval)
                {
                    var projectCtl = new ProjectControl();
                    var updatePjtCtl = new PreProjectControl();
                    var udpjt = new PendingProject();

                    udpjt.ID = project.ID;
                    udpjt.Code = project.Code;
                    //udpjt.Name = project.Name;
                    udpjt.Client = project.Client;
                    udpjt.Amount = project.Amount;
                    udpjt.Location = project.Location;

                    udpjt.ShowName = project.ShowName;
                    udpjt.Scope = project.Scope;
                    udpjt.Remark = project.Remark;
                    udpjt.Size = project.Size;
                    udpjt.Venue = project.Venue;
                    udpjt.Deadline = project.Deadline;
                    udpjt.ShowDateFrom = project.ShowDateFrom;
                    udpjt.ShowDateTo = project.ShowDateTo;
                    udpjt.Type = project.Type;
                    udpjt.Color = project.Color;
                    if (string.IsNullOrWhiteSpace(hfSelectedTeamLead.Value))
                        udpjt.StudioTeamLead = null;
                    else
                        udpjt.StudioTeamLead = Convert.ToInt32(hfSelectedTeamLead.Value);
                    udpjt.Status = Convert.ToInt32(ddlStatus.SelectedItem.Value);
                    udpjt.ProjectSales = project.ProjectSales;

                    updatePjtCtl.CreateProject(udpjt);

                    sendApprovalMail(project, udpjt);
                }
                else
                {
                    project.Status = Convert.ToInt32(ddlStatus.SelectedItem.Value);
                    ctlProject.UpdateProject(project);

                    if (!position.isSuperUser.Equals("Y"))
                        sendNonApprovalMail("U", project);
                }

            }
            else
            {
                Project project = new Project();
                int num = 1;
                string s = txtClient.Text;
                s = s.Replace(" ", "").Trim();

                if (ctlProject.GetProjects().Count() != 0)
                    num = ctlProject.GetProjects().Last().ID + 1;

                project.Code = ddlProjectType.SelectedItem.Text.Substring(0, 3) + "-" + DateTime.Now.ToString("yyyy") + "-" + num.ToString("D4") + "-" + s.Substring(0, s.Length < 4 ? s.Length : 4);
                //project.Name = txtProjectName.Text;
                project.Client = txtClient.Text;
                project.Amount = Convert.ToDouble(txtBudget.Text);
                project.ShowName = txtShowName.Text;
                project.Deadline = DateTime.ParseExact(txtDeadline.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                project.ShowDateFrom = DateTime.ParseExact(txtShowDateFrom.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                project.ShowDateTo = DateTime.ParseExact(txtShowDateTo.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                project.Color = (rColor.Text == "FFFFFF") ? "#B63849" : '#' + rColor.Text;
                project.Type = Convert.ToInt32(ddlProjectType.SelectedItem.Value);
                project.Status = Convert.ToInt32(ddlStatus.SelectedItem.Value);
                project.ProjectSales = UserId;
                if (string.IsNullOrWhiteSpace(hfSelectedTeamLead.Value))
                    project.StudioTeamLead = null;
                else
                    project.StudioTeamLead = Convert.ToInt32(hfSelectedTeamLead.Value);
                project.Location = txtLocation.Text;
                project.Scope = txtProjectScope.Text;
                project.Venue = txtVenue.Text;
                project.Remark = txtRemark.Text;
                project.Size = txtSize.Text;
                ctlProject.CreateProject(project);

                if (!position.isSuperUser.Equals("Y"))
                    sendNonApprovalMail("N", project);
            }

            Response.Redirect(EditUrl("ProjectView"));
        }

        protected void btnApprove_Click(object sender, EventArgs e)
        {
            ProjectControl ProjectCtl = new ProjectControl();
            PreProjectControl PendingProjectCtl = new PreProjectControl();
            int ID = string.IsNullOrWhiteSpace(Request.QueryString["ID"]) ? 0 : Convert.ToInt32(Request.QueryString["ID"]);
            PendingProject PendingProject = PendingProjectCtl.GetProject(ID);
            Project Project = ProjectCtl.GetProject(ID);

            Project.ID = PendingProject.ID;
            Project.Code = PendingProject.Code;
            //Project.Name = PendingProject.Name;
            Project.Client = PendingProject.Client;
            Project.ShowName = PendingProject.ShowName;
            Project.ShowDateFrom = PendingProject.ShowDateFrom;
            Project.ShowDateTo = PendingProject.ShowDateTo;
            Project.Deadline = PendingProject.Deadline;
            Project.Venue = PendingProject.Venue;
            Project.Location = PendingProject.Location;
            Project.Amount = PendingProject.Amount;
            Project.Scope = PendingProject.Scope;
            Project.Size = PendingProject.Size;
            Project.Status = PendingProject.Status;
            Project.Remark = PendingProject.Remark;
            Project.Type = PendingProject.Type;
            Project.ProjectSales = PendingProject.ProjectSales;
            Project.StudioTeamLead = PendingProject.StudioTeamLead;
            Project.Color = PendingProject.Color;

            ProjectCtl.UpdateProject(Project);
            PendingProjectCtl.DeleteProject(PendingProject);

            Response.Redirect(EditUrl("ProjectView"));
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            PreProjectControl PendingProjectCtl = new PreProjectControl();
            int ID = string.IsNullOrWhiteSpace(Request.QueryString["ID"]) ? 0 : Convert.ToInt32(Request.QueryString["ID"]);
            PendingProjectCtl.DeleteProject(ID);

            Response.Redirect(EditUrl("ProjectView"));
        }
        #endregion

        protected void sendNonApprovalMail(string action, Project pj)
        {
            ViewUserPositionControl ViewUserPositionCtl = new ViewUserPositionControl();
            var superUsers = ViewUserPositionCtl.GetSuperUsers();
            var teamLeads = ViewUserPositionCtl.GetTeamLeads();
            StringBuilder mailTo = new StringBuilder();
            StringBuilder mailCC = new StringBuilder();
            foreach (ViewUserPosition v in superUsers)
            {
                if (!string.IsNullOrWhiteSpace(mailTo.ToString()))
                    mailTo.Append(";");
                mailTo.Append(v.email);
            }

            foreach (ViewUserPosition v in teamLeads)
            {
                if (!string.IsNullOrWhiteSpace(mailCC.ToString()))
                    mailCC.Append(";");
                mailCC.Append(v.email);
            }
            
            string mailAction = action.Equals("N") ? Localization.GetString("mailSubject_NonApproval_Creation", LocalResourceFile) : action.Equals("U") ? Localization.GetString("mailSubject_NonApproval_Updated", LocalResourceFile) : string.Empty;
            string mailBodyAction = action.Equals("N") ? Localization.GetString("mailBody_NonApproval_Created", LocalResourceFile) : action.Equals("U") ? Localization.GetString("mailSubject_NonApproval_Updated", LocalResourceFile) : string.Empty;
            string mailSubject = string.Format(Localization.GetString("mailSubject_NonApproval", LocalResourceFile), mailAction);
            string mailCSS = "<style type='text/css'>a.AcceptAction{color:darkgreen;padding:6px;}a.RejectAction{color:red;padding:6px;}</style>";
            string approvalRequestLink = "http://" + Request.Url.Host + "/DesktopModules/StudioOperationSystem/API/WebApiSOS/ProjectApprovalByMail?ID=" + Convert.ToString(pj.ID) + "&Action=";
            string webLink = EditUrl(string.Empty, string.Empty, "ProjectDetails", "ID", Convert.ToString(pj.ID));
            
            StringBuilder mailBody = new StringBuilder();
            mailBody.Append(mailCSS);
            mailBody.Append(string.Format(Localization.GetString("mailBody_NonApproval", LocalResourceFile), new string[] {
                pj.Code,
                mailBodyAction,
                webLink
            }));

            SendMail(mailTo.ToString(), mailCC.ToString(), string.Empty, mailSubject, mailBody.ToString());
        }

        protected void sendApprovalMail(Project pj, PendingProject pjp)
        {
            ViewUserPositionControl ViewUserPositionCtl = new ViewUserPositionControl();

            var superUsers = ViewUserPositionCtl.GetSuperUsers();
            StringBuilder mailTo = new StringBuilder();

            foreach (ViewUserPosition v in superUsers)
            {
                if (!string.IsNullOrWhiteSpace(mailTo.ToString()))
                    mailTo.Append(";");
                mailTo.Append(v.email);
            }

            ProjectStatusControl ProjectStatusCtl = new ProjectStatusControl();
            ProjectStatus ProjectStatus = ProjectStatusCtl.GetStatus(pj.Status);
            string mailOriginAction = Localization.GetString(ProjectStatus.Name, LocalResourceFile);
            ProjectStatus = ProjectStatusCtl.GetStatus(pjp.Status);
            string mailAction = Localization.GetString(ProjectStatus.Name, LocalResourceFile);
            string mailSubject = string.Format(Localization.GetString("mailSubject", LocalResourceFile), mailAction);
            string mailCSS = "<style type='text/css'>a.AcceptAction{color:darkgreen;padding:6px;}a.RejectAction{color:red;padding:6px;}</style>";
            string approvalRequestLink = "http://" + Request.Url.Host + "/DesktopModules/StudioOperationSystem/API/WebApiSOS/ProjectApprovalByMail?ID=" + Convert.ToString(pj.ID) + "&Action=";
            string webLink = EditUrl(string.Empty, string.Empty, "ProjectDetails", "ID", Convert.ToString(pj.ID));

            StringBuilder mailBody = new StringBuilder();
            mailBody.Append(mailCSS);
            mailBody.Append(string.Format(Localization.GetString("mailBody", LocalResourceFile), new string[] {
                pj.Code,
                mailOriginAction,
                mailAction,
                approvalRequestLink + "A",
                approvalRequestLink + "R",
                webLink
            }));
            SendMail(mailTo.ToString(), string.Empty, string.Empty, mailSubject, mailBody.ToString());

        }

    }
}