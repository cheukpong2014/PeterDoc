﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Milton.Modules.StudioOperationSystem.Components;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using DotNetNuke.Entities.Users;
using DotNetNuke.Entities.Portals;
using System.Net;

namespace Milton.Modules.StudioOperationSystem
{
    /// <summary>
    /// Summary description for Handler1
    /// </summary>
    public class ApproveDesigner : StudioOperationSystemModuleBase, IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            if(context.Request.QueryString["DesignerId"] !=null)
            {
                /*
                var designerController = new DesignerController();
                int designerId = Convert.ToInt32(context.Request.QueryString["DesignerId"]);
                var _approve = designerController.GetDesigner(designerId);

                if(_approve != null)
                {

                    string response = Uri.UnescapeDataString(context.Request["Action"]);
                    response = DecryptText(response, "Milton");
                    var actMsg = "";
                    if (response == "Approve")
                    {
                        if(_approve.Status == "1")
                        {
                            context.Response.Write("This Designer has been active.");
                            context.Response.StatusCode = 200;
                            context.Response.End();
                            return;
                        }
                        _approve.Status = "1";
                        actMsg = "approved";
                    }
                    else if(response == "Reject")
                    {
                        _approve.Status = "0";
                        actMsg = "rejected";
                    }
                    else
                    {
                        context.Response.Write("Error");
                        return;
                    }

                    DotNetNuke.Entities.Modules.ModuleController mc = new DotNetNuke.Entities.Modules.ModuleController();
                    var mdSOS = mc.GetModuleByDefinition(PortalId, "StudioOperationSystem");
                    var tabID = mdSOS.TabID;
                    var mid = mdSOS.ModuleID;
                    var url = DotNetNuke.Common.Globals.NavigateURL(tabID, "DesignerView", "mid", mid.ToString());


                    var script =
                        "<script>" +
                            "windows.onLoad = function (){" +
                                "var xmlhttp;" +
                                "if (window.XMLHttpRequest)" +
                                "{" +
                                    "xmlhttp = new XMLHttpRequest();" +
                                "}" +
                                "else" +
                                "{" +
                                    "xmlhttp = new ActiveXObject(\"Microsoft.XMLHTTP\");" +
                                "}" +
                                "xmlhttp.onreadystatechange = function()" +
                                "{" +
                                    "if (xmlhttp.readyState == 4 && xmlhttp.status == 200)" +
                                    "{" +
                                         "document.write(\"We've received your input. You can close this page now.\");" +
                                    "}" +
                                "};" +
                                "var webapiUrl = '/DesktopModules/StudioOperationSystem/API/WebApiSOS/approveDesigner?DesignerId='" + designerId +
                                "xmlhttp.open(\"GET\", webapiUrl, true);" +
                                "xmlhttp.send();" +
                            "}" +
                        "</script>";
                    context.Response.ContentType = "text/HTML";
                    context.Response.Write("<!DOCTYPE html><html><head>" + script + "</head><body>Success!<br/>" + url +  "</body></html>");
                    */

            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
        public string DecryptText(string input, string password)
        {
            // Get the bytes of the string
            byte[] bytesToBeDecrypted = Convert.FromBase64String(input);
            byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
            passwordBytes = SHA256.Create().ComputeHash(passwordBytes);

            byte[] bytesDecrypted = AES_Decrypt(bytesToBeDecrypted, passwordBytes);

            string result = Encoding.UTF8.GetString(bytesDecrypted);

            return result;
        }

        public byte[] AES_Decrypt(byte[] bytesToBeDecrypted, byte[] passwordBytes)
        {
            byte[] decryptedBytes = null;

            // Set your salt here, change it to meet your flavor:
            // The salt bytes must be at least 8 bytes.
            byte[] saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

            using (MemoryStream ms = new MemoryStream())
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;

                    var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
                    AES.Key = key.GetBytes(AES.KeySize / 8);
                    AES.IV = key.GetBytes(AES.BlockSize / 8);

                    AES.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(ms, AES.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
                        cs.Close();
                    }
                    decryptedBytes = ms.ToArray();
                }
            }

            return decryptedBytes;
        }
    }
}