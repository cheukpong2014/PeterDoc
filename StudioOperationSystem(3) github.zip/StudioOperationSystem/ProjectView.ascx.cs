﻿using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Security;
using DotNetNuke.Services.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Milton.Modules.StudioOperationSystem.Components;
using DotNetNuke.Services.Exceptions;

namespace Milton.Modules.StudioOperationSystem
{
    public partial class ProjectView : StudioOperationSystemModuleBase, IActionable
    {

        public ModuleActionCollection ModuleActions
        {
            get
            {
                var actions = new ModuleActionCollection
                    {
                        {
                            GetNextActionID(), Localization.GetString("EditModule", LocalResourceFile), "", "", "",
                            EditUrl(), false, SecurityAccessLevel.Edit, true, false
                        }
                    };
                return actions;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.ClientScript.RegisterClientScriptInclude("datatable", "/Plug-in/DataTables/media/js/jquery.dataTables.min.js");
                Page.ClientScript.RegisterClientScriptInclude("datatableTableTools", "/Plug-in/DataTables/extensions/TableTools/js/dataTables.tableTools.min.js");
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "datatablesCSS", "<link rel='stylesheet' type='text/css' href='/Plug-in/DataTables/media/css/jquery.dataTables.css'>");
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "datatablesTableToolsCSS", "<link rel='stylesheet' type='text/css' href='/Plug-in/DataTables/extensions/TableTools/css/dataTables.tableTools.css'>");       

                UserPositionControl UserPositionCtl = new UserPositionControl();
                UserPosition UserPosition = UserPositionCtl.GetUserPosition(UserId);                
                ProjectTypeControl ProjectType = new ProjectTypeControl();
                ProjectControl ProjectCtl = new ProjectControl();
                if (!IsPostBack)
                {
                    if (UserPosition != null)
                    {
                        if (UserPosition.isSuperUser.Equals("Y"))
                            hfIsSuperUser.Value = "Y";
                        else
                            hfIsSuperUser.Value = "N";

                        hfUserPosition.Value = UserPosition.Position;
                    }

                    //Team Lead
                    if (!hfIsSuperUser.Value.Equals("Y") && hfUserPosition.Value.Equals("TL"))                    
                        btnCreate.Visible = false;

                    var allProject = ProjectCtl.GetProjects().ToList();
                    List<Project> filter = new List<Project>();
                    if (!IsEditable)
                    {
                        if (hfIsSuperUser.Value.Equals("Y") || hfUserPosition.Value.Equals("TL"))
                            filter = allProject;
                        else
                        {
                            foreach (var item in allProject)
                            {
                                if (item.ProjectSales == UserId)
                                {
                                    filter.Add(item);
                                    continue;
                                }
                            }
                        }                        
                    }
                    else
                        filter = allProject;

                    var result = filter.Select(projects => new newProject
                    {
                        ID = projects.ID,
                        Code = projects.Code,
                        ProjectType = ProjectType.GetProjectType(projects.Type).TypeDesc,
                        //ProjectName = projects.Name,
                        DeadLine = projects.Deadline.ToString("yyyy-MM-dd"),
                        ShowDateFrom = projects.ShowDateFrom.ToString("yyyy-MM-dd"),
                        ShowDateTo = projects.ShowDateTo.ToString("yyyy-MM-dd"),
                        Budget = projects.Amount,
                        //ShowName = projects.ShowName,
                        //ClientName = projects.Client,
                        Status = getProjectStatus(projects.ID)
                    }).ToList();

                    if (result.Count() > 0)
                    {
                        gvProject.DataSource = result;
                        gvProject.DataBind();
                        gvProject.HeaderRow.TableSection = TableRowSection.TableHeader;
                        gvProject.FooterRow.TableSection = TableRowSection.TableFooter;
                    }
                }
            }
            catch (Exception exc) //Module failed to load and report the exception
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected string getProjectStatus(int projectID)
        {
            string result = string.Empty;
            ProjectControl ProjectCtl = new ProjectControl();
            PreProjectControl PendingProjectCtl = new PreProjectControl();
            ProjectStatusControl ProjectStatusCtl = new ProjectStatusControl();
            Project Peroject = ProjectCtl.GetProject(projectID);
            PendingProject PendingProject = PendingProjectCtl.GetProject(projectID);
            ProjectStatus ProjectStatus;
            if (PendingProject != null)
            {
                ProjectStatus = ProjectStatusCtl.GetStatus(PendingProject.Status - 1);

                if (ProjectStatus != null)                
                    result = Localization.GetString(ProjectStatus.Name, LocalResourceFile);
                else                
                    result = Localization.GetString("NA", LocalResourceFile);              
            }
            else
            {
                ProjectStatus = ProjectStatusCtl.GetStatus(Peroject.Status);

                if (ProjectStatus != null)
                    result = Localization.GetString(ProjectStatus.Name, LocalResourceFile);
                else
                    result = Localization.GetString("NA", LocalResourceFile);
            }

            return result;
        }

        protected void gvTable_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            e.Row.Cells[0].CssClass = "hiddenColumn";            
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            Response.Redirect(EditUrl("ID", "", "ProjectDetails"));
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL());
        }
    }
}

public class newProject
{
    public int ID { get; set; }
    public string Code { get; set; }
    public string ProjectType { get; set; }
    //public string ProjectName { get; set; }
    public string DeadLine { get; set; }
    public string ShowDateFrom { get; set; }
    public string ShowDateTo { get; set; }
    //public string ShowName { get; set; }
    //public string ClientName { get; set; }
    public double Budget { get; set; }
    public string Status { get; set; }
}